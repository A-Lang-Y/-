$(document).ready(function() {

	$('.profesional').hover(function() {
		$(".profesional_mid").animate({height: '64px'}, {queue: false});
	}, function(){
		$(".profesional_mid").animate({height: '0px'}, {queue: false});
		});
		
		
$('#basicuse').jflickrfeed({
limit: 6,
qstrings: {
	id: '52617155@N08'
},
itemTemplate: '<li><a href="{{image_b}}"><img src="{{image_s}}" alt="{{title}}" /></a></li>'
});
$("#twitter1").getTwitter({
	userName: "fiximgfx",
	numTweets: 3,
	loaderText: "Loading tweets...",
	slideIn: true,
	slideDuration: 750,
	showHeading: false,
	headingText: "Latest Tweets",
	showProfileLink: false,
	showTimestamp: true
});		


});
	document.createElement("header");
	document.createElement("section");
	document.createElement("nav");
	document.createElement("aside");
	document.createElement("footer");
	document.createElement("article");
	
	
	$(document).ready(function() {

	$('.profesional').hover(function() {
		$(".profesional_mid").animate({height: '64px'}, {queue: false});
	}, function(){
		$(".profesional_mid").animate({height: '0px'}, {queue: false});
		});
		
		
$('#basicuse').jflickrfeed({
limit: 6,
qstrings: {
	id: '52617155@N08'
},
itemTemplate: '<li><a href="{{image_b}}"><img src="{{image_s}}" alt="{{title}}" /></a></li>'
});
$("#twitter").getTwitter({
	userName: "fiximgfx",
	numTweets: 3,
	loaderText: "Loading tweets...",
	slideIn: true,
	slideDuration: 750,
	showHeading: false,
	headingText: "Latest Tweets",
	showProfileLink: false,
	showTimestamp: true
});		


});
	document.createElement("header");
	document.createElement("section");
	document.createElement("nav");
	document.createElement("aside");
	document.createElement("footer");
	document.createElement("article");
//menu
$(document).ready(function(){
   $("#menu").click(function(){
      $("#guide").slideToggle();
   })
})
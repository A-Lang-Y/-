Cufon.replace('h2, h3, #menu a, h4, h5, .tabs ul.nav li a, h6', { fontFamily: 'Swis721 Cn BT', hover:true });


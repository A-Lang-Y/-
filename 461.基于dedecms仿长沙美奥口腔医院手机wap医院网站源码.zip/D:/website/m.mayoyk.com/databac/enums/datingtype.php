<?php
global $em_datingtypes;
$em_datingtypes = array();
$em_datingtypes['1'] = '网友';
$em_datingtypes['2'] = '恋人';
$em_datingtypes['3'] = '玩伴';
$em_datingtypes['4'] = '共同兴趣';
$em_datingtypes['5'] = '男性朋友';
$em_datingtypes['6'] = '女性朋友';
?>
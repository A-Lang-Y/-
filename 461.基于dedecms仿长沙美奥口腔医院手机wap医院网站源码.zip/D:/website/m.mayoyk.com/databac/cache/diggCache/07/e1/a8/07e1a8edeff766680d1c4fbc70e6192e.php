<?php exit('dedecms');?>
a:2:{s:4:"data";a:3:{s:8:"goodpost";i:1;s:7:"badpost";s:1:"0";s:6:"scores";s:1:"0";}s:7:"timeout";i:0;}
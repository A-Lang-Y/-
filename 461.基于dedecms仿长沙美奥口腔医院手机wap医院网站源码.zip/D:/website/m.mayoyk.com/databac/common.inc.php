﻿
<?php
//数据库连接信息
$cfg_dbhost = 'localhost';
$cfg_dbname = 'mayoykmobile';
$cfg_dbuser = 'wanghao';
$cfg_dbpwd = 'wanghao';
$cfg_dbprefix = 'szmayoM_';
$cfg_db_language = 'utf8';


?>
Home page with introduction:
http://vadikom.com/tools/poshy-tip-jquery-plugin-for-stylish-tooltips/
Cufon.replace('h3', { fontFamily: 'PT Sans', hover:true });
Cufon.replace('h1 em', { fontFamily: 'PT Sans', hover:true });
Cufon.replace('.main-menu a, h4', { fontFamily: 'Satisfy', hover:true });
Cufon.replace('.list-services > li', { fontFamily: 'NewsGoth', hover:true });

jQuery(document).ready(function($) {
    $('#form1').jqTransform({imgPath:'jqtransformplugin/img/'});	
});

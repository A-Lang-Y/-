var b_txt = '';

// write the badge
	
	
		 	 	 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image1"><a href="http://www.flickr.com/photos/elmastudio/7119927013/"><img src="http://farm8.staticflickr.com/7257/7119927013_c02fa37153_t.jpg" alt="A photo on Flickr" title="My KeepCup ♥" height="100" width="100"></a></div>';
	
		 	 	 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image2"><a href="http://www.flickr.com/photos/elmastudio/3828498700/"><img src="http://farm4.staticflickr.com/3486/3828498700_4bccbffca3_t.jpg" alt="A photo on Flickr" title="Spring Flower Magnolia" height="100" width="75"></a></div>';
	
		 	 	 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image3"><a href="http://www.flickr.com/photos/elmastudio/7231715612/"><img src="http://farm9.staticflickr.com/8161/7231715612_fed7e81446_t.jpg" alt="A photo on Flickr" title="Whale Bay Weekend Trip" height="100" width="100"></a></div>';
	
		 	 	 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image4"><a href="http://www.flickr.com/photos/elmastudio/4071941586/"><img src="http://farm3.staticflickr.com/2521/4071941586_8197dec0ba_t.jpg" alt="A photo on Flickr" title="Auckland Harbour Bridge, we are back :-)" height="69" width="100"></a></div>';
	
		 	 	 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image5"><a href="http://www.flickr.com/photos/elmastudio/4298760995/"><img src="http://farm3.staticflickr.com/2757/4298760995_139b5cd079_t.jpg" alt="A photo on Flickr" title="Art in my coffee" height="73" width="100"></a></div>';
	
		 	 	 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image6"><a href="http://www.flickr.com/photos/elmastudio/4108516344/"><img src="http://farm3.staticflickr.com/2600/4108516344_3f5a7eff39_t.jpg" alt="A photo on Flickr" title="Dreaming and Enjoying" height="75" width="100"></a></div>';
	
		 	 	 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image7"><a href="http://www.flickr.com/photos/elmastudio/7046898709/"><img src="http://farm8.staticflickr.com/7177/7046898709_709037ecb7_t.jpg" alt="A photo on Flickr" title="Ellerslie Car Fair in Auckland" height="75" width="100"></a></div>';
	
		 	 	 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image8"><a href="http://www.flickr.com/photos/elmastudio/7046903209/"><img src="http://farm8.staticflickr.com/7090/7046903209_984120799e_t.jpg" alt="A photo on Flickr" title=" " height="75" width="100"></a></div>';
	
		 	 	 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image9"><a href="http://www.flickr.com/photos/elmastudio/4177235113/"><img src="http://farm3.staticflickr.com/2702/4177235113_dfc96f7c01_t.jpg" alt="A photo on Flickr" title="Auckland Harbor Bridge" height="71" width="100"></a></div>';


b_txt += '<span style="position:absolute;left:-999em;top:-999em;visibility:hidden" class="flickr_badge_beacon"><img src="http://geo.yahoo.com/p?s=792600102&t=f94599f36122bd90c9c085984e163e25&r=http%3A%2F%2Fyoko.elmastudio.de%2F&fl_ev=0&lang=en&intl=us" width="0" height="0" alt="" /></span>';

document.write(b_txt);
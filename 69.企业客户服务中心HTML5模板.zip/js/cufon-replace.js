Cufon.replace('.font-2, h3,.block-2 p', { fontFamily: 'Vegur-M', hover:true});
Cufon.replace('.font-1, .banner a, .block-2 a', { fontFamily: 'Vegur-L', hover:true});
Cufon.replace('h2, .color-3', { fontFamily: 'Vegur-R', hover:true});
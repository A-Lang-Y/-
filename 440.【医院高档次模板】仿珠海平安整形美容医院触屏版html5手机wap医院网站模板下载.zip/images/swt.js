document.write('<div id="swtJs" style="z-index:3347483647; display:block; width:34px; height:63px; position:fixed;_position:absolute;top:40%; right:0%; _top:expression(offsetParent.scrollTop+document.documentElement.clientHeight-this.offsetHeight)"><a href="../www.zhpingan.com/call/@wap" onclick="LR_HideInvite();openZoosUrl();return false;"><img src="images/online_cn.gif" border="0"></a></div><div style="display:none; width:0px;"><script language=\"javascript\" src=\"../www.zhpingan.com/call/@wap"></script></div>');


















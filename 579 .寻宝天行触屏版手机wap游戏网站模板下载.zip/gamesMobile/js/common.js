﻿

	//首页需要的tab切换效果_begin
	var indexTabSwich = function(tabNum,tabParentId,tabId,radioId,radioClass,tabDisplacement,div_red_line) {
		this.tabNum = tabNum;//要切换的tab的数量
		this.tabParentId=tabParentId;//要切换的tab的父元素
		this.tabId=tabId;//要切换的tab的Id
		this.radioId=radioId;//要切换的tab下面的指示圆点
		this.tabDisplacement=tabDisplacement;//向左向右的位移
		this.radioClass=radioClass;//指示圆点的样式
		this.div_red_line=div_red_line;
	};
	indexTabSwich.prototype.tabSwich=function(){
		var leftPositonValue=0;
		var tempCount=0;
		var _this=this;
		if(_this.radioId!=""){
			$("#"+_this.radioId).find("li").eq(0).addClass(_this.radioClass);
		}		
		
		$("#"+_this.tabParentId).swipeleft(function(){		
			if(leftPositonValue>-(_this.tabDisplacement*(_this.tabNum-1))){				
				leftPositonValue=leftPositonValue-_this.tabDisplacement;
				$("#"+_this.tabId).animate({left:leftPositonValue+"px"},300);
				if(_this.radioId!=""){
					var radionPos=-(leftPositonValue/_this.tabDisplacement);
					$("#"+_this.radioId).find("li").removeClass(_this.radioClass).eq(radionPos).addClass(_this.radioClass);
				}
				if(_this.div_red_line!=""){
					tempCount++;
					if(tempCount<_this.tabNum){
						$("#"+_this.div_red_line).find("span").removeClass("sel");
						$("#"+_this.div_red_line).find("span").eq(tempCount).addClass("sel");
					}
					
				}
			}
		});
		$("#"+_this.tabParentId).swiperight(function(){
			if(leftPositonValue<0){
				leftPositonValue=leftPositonValue+_this.tabDisplacement;
				$("#"+_this.tabId).animate({left:leftPositonValue+"px"},300);
				if(_this.radioId!=""){
					var radionPos=-(leftPositonValue/_this.tabDisplacement);;
					$("#"+_this.radioId).find("li").removeClass(_this.radioClass).eq(radionPos).addClass(_this.radioClass);
				}	
				if(_this.div_red_line!=""){
					tempCount--;
					if(tempCount>=0){
						$("#"+_this.div_red_line).find("span").removeClass("sel");
						$("#"+_this.div_red_line).find("span").eq(tempCount).addClass("sel");
					}
					
				}
			}	
		});		
	}; 
	//首页需要的tab切换效果_end
	
	$("document").ready(function(){
		//回顶部_begin
		$("#imge_backToTop").live("click",function(){
			$("body").animate({scrollTop:0},100);
		});
		$("#f_backToTop").live("click",function(){
			$("body").animate({scrollTop:0},100);
		});
		//回顶部_end

		
		
	});
	
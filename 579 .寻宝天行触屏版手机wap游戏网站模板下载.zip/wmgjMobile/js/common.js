﻿	jQuery.extend({
    log: function(msg) {//日志终端输出
        if (window.console) {
            if (typeof msg == "object") {
                var html = [];
                for (var i in msg) {
                    html[html.length] = 'name: ' + i + " value: " + msg[i] + '\n';
                }
                window.console.log(html.join(""));
            } else {
                window.console.log(msg);
            }
        }
    },
    getEvt: function(e) {//获得事件和事件源
        var evt = e || window.event;
        var evtTar = evt.target || evt.srcElement;
        if (evtTar.nodeType == 3) {
            evtTar = evtTar.parentNode;
        }
        return [evt, evtTar];
    },
    stopB: function(e) {//阻止事件冒泡
        var evt = e || window.event;
        if (evt.stopPropagation) {
            evt.stopPropagation();
        } else {
            evt.cancelBubble = true;
        }
    },
	getScrollTop : function (){
		return  document.documentElement.scrollTop || document.body.scrollTop;
	},
	setScrollTop : function (top){
		var de = document.documentElement || document.body;
    	de.scrollTop = top;
	},
	getScrollLeft : function (){
		return document.documentElement.scrollLeft || document.body.scrollLeft;
	}
	});
	(function (window){
		var u = {
				getUrlParam : function(name) {// 给定URL参数名称取得对应的参数
					var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
					if (reg.test(location.search.substr(1))) {
						return decodeURIComponent(RegExp.$2);
					} else {
						return "";
					}
				},
				getCurrentParams:function (obj){
					obj = obj || {};
					function getParams(param){
						var value = U.getUrlParam(param);
						if(value)
							return param + "=" + U.getUrlParam(param);
						else
							return "";
					}
					var params = [];
					var zonegroup = getParams('zonegroup');

					if(zonegroup){
						params.push(zonegroup);
					}
					var zoneid = getParams('zoneid');
					if(zoneid){
						params.push(zoneid);

					}
					var servernameforsearch = getParams('servernameforsearch');
					if(servernameforsearch){
						params.push(servernameforsearch);

					}
					if(obj.page!='page'){
						var page = getParams('page');
						if(page){
							params.push(page);
					
						}
					}
					if(obj.orderBy!='orderBy'){
						var orderBy = getParams('orderBy');
						if(orderBy){
							params.push(orderBy);

						}
					}
					if(obj.keyWord!='keyWord'){
						var keyWord = getParams('keyWord');
						if(keyWord){
							params.push(keyWord);
					
						}
					}
					return params.length>0 ? params.join("&") : "";
					
					

				}
		};
		window.U = u;
	})(window);
	
	var numCheck=function(){
		
	};
	numCheck.prototype.check_integer=function(value){
		 if (/^(\+)?\d+$/.test(value)) {  
		    	if(parseInt(value)>0)
		    		return true;    
		 }     
		 return false; 
	};
	
	numCheck.prototype.check_float=function(value, isRole){
		if (/^(\+)?\d+($|\.\d{1,2}$)/.test(value)){    
	    	if(parseFloat(value)>=10 && parseFloat(value)<=1000000 && !isRole) {
	    		return true;   
	    	} else if(parseFloat(value)>=60 && parseFloat(value)<=1000000 && isRole) {
	    		return true;
	    	}
	    }     
	    return false; 
	};
	numCheck.prototype.parseDate=function(string){
		var results = string.match(/(\d{4})-(\d{2})-(\d{2}) +(\d{1,2}):(\d{1,2})/); 
		return new Date(parseInt(results[1]),parseInt(results[2],10)-1,parseInt(results[3], 10), parseInt(results[4],10), parseInt(results[5], 10));
	};
	
	//服务器列表选项_begin
	var serverChoose=function(serverContainId,serverZoneClass,severAreaClass,showNum,moreId,upDownEle,downClass,upClass){
		this.serverContainId=serverContainId;//“选服选区”父元素Id
		this.serverZoneClass=serverZoneClass;//“服务器”标识样式
		this.severAreaClass=severAreaClass;//“游戏大区”标识样式
		this.showNum=showNum;//页面初始化时显示的服务器的个数
		this.moreId=moreId;//“更多”按钮Id
		this.downClass=downClass;//“下拉”箭头样式
		this.upClass=upClass;//“上拉”箭头样式
		this.upDownEle=upDownEle;//“上拉”,“下拉”箭头盛放元素
	};
	
	serverChoose.prototype.severControl=function(){//初始化以及点击事件
		var _this=this;
		
		var severZoneList=$("#"+_this.serverContainId).find("."+_this.serverZoneClass);//服务器列表
		var serverAreaList=$("#"+_this.serverContainId).find("."+_this.severAreaClass);//大区列表
		serverAreaList.each(function(){
			var listThis=$(this);
			$(this).find("a").each(function(i){
				if((i+1)%3==0){
					$(this).addClass("a2");
				}
				var aSize=listThis.find("a").size();
				if(i==aSize-1){
					$(this).addClass("a2");
				}
			});
		});
		serverAreaList.hide();//隐藏所有的大区
		severZoneList.hide();//隐藏所有的服务器
		if(severZoneList.size()<=_this.showNum){//如果服务器的总数小于页面初始显示数量时
			severZoneList.show();//显示所有的服务器
			$("#"+_this.moreId).hide();//“更多”按钮隐藏 注意：默认情况下是显示“更多”按钮的
			$("#"+_this.moreId).parent("li.more").hide();//隐藏“更多”按钮父元素的占位
		}else{//当大于这个数量时
			$("#"+_this.serverContainId).find("."+_this.serverZoneClass+":lt("+_this.showNum+")").show();//显示showNum个服务器元素
		}
		
		severZoneList.each(function(i){//当点击某一个服务器时		
			$(this).click(function(){
				if($(this).find(_this.upDownEle).attr("class")==_this.downClass){//当发现状态标识元素处于向下的状态时，说明改行可点击并下拉出大区列表
					$(this).parent("#"+_this.serverContainId).find("."+_this.severAreaClass).slideUp();//收起所有的大区列表
					$("#"+_this.serverContainId).find("li."+_this.serverZoneClass).find(_this.upDownEle).attr("class",_this.downClass);//把所有的服务器标识状态改为向下
					$(this).next("ul").slideDown();//显示当前触发事件的服务器的大区列表
					$(this).find(_this.upDownEle).attr("class",_this.upClass);//把当前触发事件的元素的状态改为向上
					
				}else if($(this).find(_this.upDownEle).attr("class")==_this.upClass){//当发现状态标识元素处于向上的状态时，说明该行已被点击并显示出大区列表，再次点击该服务器时应该收起大区列表，并改为向下的标识
					$(this).next("ul").slideUp();//收起大区列表
					$(this).find(_this.upDownEle).attr("class",_this.downClass);//把向上的箭头改为向下
				}
				return false;
			});
		});
		
		var severZoneModuleSize=Math.ceil(severZoneList.size()/_this.showNum);
		var tempCount=1;
		$("#"+_this.moreId).click(function(){//点击“更多”按钮
			serverAreaList.hide();
			$(_this.upDownEle+"."+_this.upClass).attr("class",_this.downClass);
			var showEnd=(tempCount+1)*_this.showNum;
			$("#"+_this.serverContainId).find("."+_this.serverZoneClass+":lt("+showEnd+")").show();
			if(tempCount+1==severZoneModuleSize){
				$("#"+_this.moreId).hide();
			}else{
				tempCount++;
			}
			
		});
		
	};
	//服务器列表选项_end
	
	//物品信息显示_begin
	var parseItem=function(itemText,detailShowId){
		this.itemText=itemText;
		this.detailShowId=detailShowId;
	};
	parseItem.prototype.itemParse=function(){//物品信息解析函数（非完美币，非角色）
		var _this=this;
		var s = $.trim(_this.itemText).replace(/\s/g, '&nbsp;') + '&nbsp;&nbsp;&nbsp;';
		var array = new Array;
		var lastColor = "ffffff";
		array.push("<font style='color:#" + lastColor + "'>");
		var re= /\^\w{6}/;
		for(var i = 0; i < s.length;) {
			var c = s.charAt(i);
			var temp = s.substring(i, i+7);
			var result = temp.match(re);
			if(result) {
				array.push("</font><font style='color:#" + temp.substring(1) + "'>" );
				lastColor = temp.substring(1);
				i=i+7;
			}else if(c == '\\' && s.charAt(i+1) == 'r') {
				array.push("</font><br/><font style='color:#" + lastColor + "'>" );
				i=i+2;
			} else {
				array.push(s.charAt(i));
				i++;
			}
		}
		array.push("&nbsp;</font>");
		var serializeText=array.join("");
		return serializeText;
		//相关的容器显示内容
	};
	parseItem.prototype.parseUnEquip=function(){//完美币，角色解析函数
		var _this=this;
		var serializeText="<font style='color:#ffffff'>"+_this.itemText+"</font>";
		return serializeText;
	};
	parseItem.prototype.itemShow=function(){
		var _this=this;
		var isRole=$("#hiddenisROLE").attr("value");
		if(isRole=="true"){
			var detailTextFomat=_this.parseUnEquip(_this.itemText);
		}else{
			var detailTextFomat=_this.itemParse(_this.itemText);
		}
		
		$("#"+_this.detailShowId).html(detailTextFomat);
	};
	//物品信息显示_end
	
	//我要买，具有物品详细信息的物品展示列表所需的上拉下拉效果_begin
	var goodsItemControl=function(goodsItemEle,goodsItemClass,
			itemStatusEle,itemStatusFlagClass,upClass,downClass,
			ItemDetailEle,itemDetailClass,
			showNum,moreId,
			detailText,
			moneyFlagClass,moneyNumClass,moneyPriceClass,moneyNameClass){
			this.goodsItemEle=goodsItemEle;//物品列表元素名
			this.goodsItemClass=goodsItemClass;//物品列表标识样式
			this.itemStatusEle=itemStatusEle;//显示状态元素名
			this.itemStatusFlagClass=itemStatusFlagClass;//状态元素标识样式
			this.upClass=upClass;//上三角样式
			this.downClass=downClass;//下三角样式
			this.ItemDetailEle=ItemDetailEle;//物品详细信息列元素名
			this.itemDetailClass=itemDetailClass;//物品详细信息列标识样式
			this.showNum=showNum;//每次显示的数据数
			this.moreId=moreId;//“更多”按钮Id
			this.detailText=detailText;//物品详情数据
			this.moneyFlagClass=moneyFlagClass;//完美币标识样式
			this.moneyNumClass=moneyNumClass;//完美币数量标识样式
			this.moneyPriceClass=moneyPriceClass;//完美币价格标识样式
			this.moneyNameClass=moneyNameClass;//完美币or完美银票
		};
		/*goodsItemControl.prototype.parseItemDetailFunction=function(){
			var _this=this;
			$(_this.goodsItemEle+"."+_this.goodsItemClass).each(function(){
				
			});
		};*/
		goodsItemControl.prototype.itemControl=function(){
			var _this=this;
			var itemList=$(_this.goodsItemEle+"."+_this.goodsItemClass);
			$(_this.goodsItemEle+"."+_this.goodsItemClass).hide();
			$(_this.ItemDetailEle+"."+_this.itemDetailClass).hide();
			if(itemList.size()<=_this.showNum){//当列表中的数据大于初始要显示的数据的值时，隐藏“更多”按钮
				
				$("#"+_this.moreId).hide();
				
				$("#"+_this.moreId).parents("ul.moreButtonFlag").hide();
				$(_this.goodsItemEle+"."+_this.goodsItemClass).show();
			}else{
				$(_this.goodsItemEle+"."+_this.goodsItemClass+":lt("+_this.showNum+")").show();
			}
			$(_this.goodsItemEle+"."+_this.goodsItemClass+":even").attr("class","goodsItem list2_1 list2_1none");//基数元素_修改标记
			$(_this.goodsItemEle+"."+_this.goodsItemClass+":even").next("div").attr("class","shir_item_detail J_Preview_even");
			$(_this.goodsItemEle+"."+_this.goodsItemClass+":odd").attr("class","goodsItem list2_1 arrow_right list2_1none");//偶数元素
			$(_this.goodsItemEle+"."+_this.goodsItemClass+":odd").next("div").attr("class","shir_item_detail J_Preview_even");
			$(_this.goodsItemEle+"."+_this.goodsItemClass).each(function(){
				$(this).click(function(e){
					if($(this).find("div.itemImageFlag").find("a").hasClass("tempFlagClass")){
						return false;
					}
					if($(this).find("a.daRenFlag").hasClass("daRenClickFlag")){
						return false;
					}
					if($(this).find(_this.itemStatusEle+"."+_this.itemStatusFlagClass).hasClass(_this.downClass)){
						//alert("OK");
						$(_this.ItemDetailEle+"."+_this.itemDetailClass).hide();//隐藏已经显示的物品信息
						$(_this.itemStatusEle+"."+_this.itemStatusFlagClass+"."+_this.upClass).removeClass(_this.upClass).addClass(_this.downClass);//将上三角标记变为下三角标记
						$(this).find(_this.itemStatusEle+"."+_this.itemStatusFlagClass).attr("class",_this.itemStatusFlagClass+" "+_this.upClass);//将当前点击项的下三角标记变为上三角标记
						var detailText=$(this).next(_this.ItemDetailEle+"."+_this.itemDetailClass).find("."+_this.detailText).html();
						var oParseItem=new parseItem(detailText);//解析物品详细信息
						var moneyFlag=$(this).next(_this.ItemDetailEle+"."+_this.itemDetailClass).find("."+_this.moneyFlagClass).attr("value");
						var moneyNum=$(this).next(_this.ItemDetailEle+"."+_this.itemDetailClass).find("."+_this.moneyNumClass).attr("value");
						var moneyPrice=parseFloat($(this).next(_this.ItemDetailEle+"."+_this.itemDetailClass).find("."+_this.moneyPriceClass).attr("value"));
						var moneyName=$(this).next(_this.ItemDetailEle+"."+_this.itemDetailClass).find("."+_this.moneyNameClass).attr("value");
						var itemText=oParseItem.itemParse();
						if(moneyFlag=="true"){//如果所展示的物品为完美币或者完美银票的话，需要加上单价信息					
							var textAppend=_this.uitPrice(moneyNum,moneyPrice,moneyName);
							itemText=itemText+textAppend;
						}
						$(this).next(_this.ItemDetailEle+"."+_this.itemDetailClass).find(".detailContain").html(itemText);
						$(this).next(_this.ItemDetailEle+"."+_this.itemDetailClass).slideDown();//对应的详情状态下拉显示（在下拉显示之前就应该把物品的展示信息解析出来）
					}else if($(this).find(_this.itemStatusEle+"."+_this.itemStatusFlagClass).hasClass(_this.upClass)){
						$(this).find(_this.itemStatusEle+"."+_this.itemStatusFlagClass).attr("class",_this.itemStatusFlagClass+" "+_this.downClass);
						$(this).next(_this.ItemDetailEle+"."+_this.itemDetailClass).slideUp();
					}
					
				});
			});
			$("div.itemImageFlag a").each(function(){
				$(this).click(function(){
					var itemHiddenCommid=$(this).parent(".itemImageFlag").find("input.itemHiddenCommid").attr("value");
					var url=location.href; 
					var shopid=U.getUrlParam("shopid");
					if(shopid!=""&&shopid!=null){//"达人"部分点击图片跳转时需要走一下getServerList
						//location.href=$("#basePathId").attr("value")+"buyDetail.gsp"+"?"+"commid="+itemHiddenCommid+"&"+"shopid="+shopid;
						location.href=$("#basePathId").attr("value")+"getServerList"+"?"+"commid="+itemHiddenCommid+"&"+"shopid="+shopid;
					}else{
						var pageHiddenpage=$(this).parent(".itemImageFlag").find("input.pageHiddenpage").attr("value");
						var oBuyButton=new buyButton(itemHiddenCommid,pageHiddenpage,'keyword');
						$(this).addClass("tempFlagClass");
						oBuyButton.linkTo();
					}
					
					
					
				});
			});
			
			if($("a.daRenFlag").size()!=0){
				var _this=this;
				$("a.daRenFlag").each(function(){
					$(this).click(function(){
						var shopidVlaue=$(this).prev().prev("input.daRenShopId").attr("value");
						var basePathValue=$(this).prev("input.webBasePath").attr("value");
						$(this).addClass("daRenClickFlag");
						/*var url=location.href;
						if(url.indexOf("?")!=-1){
							url=url.substring(0, url.indexOf("?"));
						}*/
						location.href=basePathValue+"search@shopid="+shopidVlaue;
					});
				});
			}
			
			/*$("a.daRenFlag").each(function(){
				$(this).click(function(){
					$(this).addClass("daRenClickFlag");
				});
			});*/
			
			var ModuleSize=Math.ceil(itemList.size()/_this.showNum);
			var tempCount=1;
			$("#"+_this.moreId).click(function(){
				$(_this.ItemDetailEle+"."+_this.itemDetailClass).hide();
				$(_this.itemStatusEle+"."+_this.itemStatusFlagClass+"."+_this.upClass).removeClass(_this.upClass).addClass(_this.downClass);
				var showEnd=(tempCount+1)*_this.showNum;
				$(_this.goodsItemEle+"."+_this.goodsItemClass+":lt("+showEnd+")").slideDown();
				
				if (tempCount + 1 == ModuleSize) {
					$("#" + _this.moreId).hide();
				} else {
					tempCount++;
				}
			});
		};
		goodsItemControl.prototype.uitPrice=function(moneyNum,moneyPrice,moneyType){//完美币，完美银票单价解析
			var unitPrice=0;
			var text="";
			var f_moneyNum=parseFloat(moneyNum.split(',').join(""));
			if(moneyType.indexOf("完美币")!=-1){
				unitPrice = (moneyPrice / (f_moneyNum / 1000000)).toPrecision(10).toString();
		        text += "<br/><font style='color:#FFFFFF;'>单价：" + unitPrice + " 元/百万完美币</font>";
			}else if(moneyType.indexOf("完美银票")!=-1){
				unitPrice = (moneyPrice /f_moneyNum).toPrecision(10).toString();
		        text += "<br/><font style='color:#FFFFFF;'>单价：" + unitPrice + " 元/张完美银票</font>";
			}
			return text;
		};
		goodsItemControl.prototype.detailHide=function(){//详细信息部分上三角点击触发事件
			var _this=this;
			$(_this.ItemDetailEle+"."+_this.itemDetailClass).find("."+_this.upClass).click(function(){//具体操作标签待定
				$(this).parents(_this.ItemDetailEle+"."+_this.itemDetailClass).slideUp();
				$(this).parents(_this.ItemDetailEle+
						"."+_this.itemDetailClass).prev(_this.goodsItemEle+
						"."+_this.goodsItemClass).find(_this.itemStatusEle+
						"."+_this.itemStatusFlagClass+
						"."+_this.upClass).removeClass(_this.upClass).addClass(_this.downClass);
			});
		};
	//我要买，具有物品详细信息的物品展示列表所需的上拉下拉效果_end
	
	
		
	//有关物品排序的相关控制_begin
		var goodSortControl=function(sortEleId,sortOptionContainEleId,optionEle,searchInputId){
			this.sortEleId=sortEleId;
			this.sortOptionContainEleId=sortOptionContainEleId;
			this.optionEle=optionEle;
			this.searchInputId=searchInputId;
		};
		goodSortControl.prototype.sortToggleControl=function(){//排序列表的显示与隐藏
			var _this=this;
			$("#"+_this.sortEleId).click(function(){
				$("#"+_this.sortOptionContainEleId).slideToggle();
			});
		};
		goodSortControl.prototype.sortControl=function(){//跳转控制
			var _this=this;
			var url = location.href; 
			var currentGroup = "";     	
	     	var orderByNow="";
	     	var orderByText="";
	     	var keyWord="";
	     	var shopid="";
	     	var zonegroup="";
	     	var zoneid="";
	     	if(url.indexOf("?") > 0) {
	   			var group0 = U.getUrlParam('group0');
	  			var group1 = U.getUrlParam('group1');
					if(group1) {
						currentGroup = '&group0=' + group0 + '&group1=' + group1;
		   			} else if(group0) {
						currentGroup = '&group0=' + group0;
		   			} 
					orderByNow=U.getUrlParam("orderBy");
					keyWord=U.getUrlParam("keyWord");
					shopid=U.getUrlParam("shopid");
					zonegroup=U.getUrlParam('zonegroup');
					zoneid=U.getUrlParam('zoneid');
					orderByText=$("#"+_this.sortOptionContainEleId).find("[orderBy='"+orderByNow+"']").attr("orderByText");
					if(orderByText==null){
						orderByText="默认排序";
						orderByNow="default";
					}
	   		}else{
	   			orderByText="默认排序";
				orderByNow="default";
	   		}
			if (url.indexOf("?") > 0) {
				if(shopid!=null&&shopid!=""){
					url = url.substring(0,url.indexOf("?"))+"@shopid="+shopid+"&";
				}else{
					url = url.substring(0,url.indexOf("?"))+"?";				
				} 		
			}else{
				url=url+"?";
			}			
			$("#"+_this.sortEleId).html("<span>"+orderByText+"</span>");
			$("#"+_this.sortOptionContainEleId).find(_this.optionEle).removeClass("cur");
			$("#"+_this.sortOptionContainEleId).find("[orderBy='"+orderByNow+"']").addClass("cur");
			
			$("#"+_this.sortOptionContainEleId).find(_this.optionEle).each(function(){
				$(this).click(function(){
					if(shopid!=null&&shopid!=""){
						if(zonegroup!=null&&zonegroup!=""){
							url = url + encodeURI("orderBy="+$(this).attr("orderBy")) 
							+ "&"+"zonegroup="+zonegroup + "&keyWord=" +keyWord;
							if(zoneid!=null&&zoneid!=""){
								url = url + "&zoneid="+zoneid;
							}
						}else{
							url = url + encodeURI("orderBy="+$(this).attr("orderBy")) 
							+ currentGroup + "&keyWord=" +keyWord;
						}
					}else{
						url = url + encodeURI("orderBy="+$(this).attr("orderBy")) 
						+ currentGroup + "&keyWord=" +keyWord;
					}
					
   					location.href = url;
				});
			});
		};
		goodSortControl.prototype.sortShow=function(){//排序装状态显示
			var _this=this;
			var url=location.href;;
			
		};
	//有关物品排序的相关控制_end
		
	//搜索框操作函数_begin
		var searchInput=function(searchInputId,searchButtonId){
			this.searchInputId=searchInputId;
			this.searchButtonId=searchButtonId;
		};
		searchInput.prototype.searchNow=function(){
			var _this=this;
			$("#"+_this.searchButtonId).click(function(){
				var keyWord = $.trim($("#"+_this.searchInputId).val());
				var url = location.href; 
		  		if(url.indexOf("?") > 0) {
		  			url = url.substring(0,url.indexOf("?"));
		  		}
				location.href = url + "@orderBy=unitprice-asc&keyWord=" + encodeURI(keyWord);
				return false;
			});
		};
	//搜索框操作函数_end
	
	//列表页_购买按钮点击操作_begin
	var buyButton=function(commid,page,searchInputId){
		this.commid=commid;
		this.page=page;
		this.searchInputId=searchInputId;
	};
	buyButton.prototype.linkTo=function() {
		var _this=this;
		var url = location.href; 
     	var currentGroup = "";
     	var orderByValue="";
     	if(url.indexOf("?") > 0) {
   			var group0 = U.getUrlParam('group0');
  			var group1 = U.getUrlParam('group1');
				if(group1) {
					currentGroup = '&group0=' + group0 + '&group1=' + group1;
	   			} else if(group0) {
					currentGroup = '&group0=' + group0;
	   			} 
				orderByValue=U.getUrlParam('orderBy');
   		}
		location.href = "buyDetail.gsp@commid="+ _this.commid+ "&page=" 
		+ _this.page + currentGroup + "&keyWord=" 
		+ encodeURI($("#"+_this.searchInputId).val()) + "&orderBy="+orderByValue+"&"
		+U.getCurrentParams({orderBy:'orderBy',keyWord:'keyWord',page:'page'});
		return false;
	};
	
	//列表页_购买按钮点击操作_end
	
	//分页操作_新_begin
	
	var newPageing=function(){
		
	};
	newPageing.prototype.pageControl=function(){
		var _this=this;
		_this.newPageInit();
		_this.goFirstPage();
		_this.goLastPage();
		_this.goPrevPage();
		_this.goNextPage();
		_this.inputGoPage();
	};
	newPageing.prototype.newPageInit=function(){//页面分页初始化函数
		/*
		 * 思路：要考虑两种情况
		 * 第一：当这个列表只有一页的时候，初始化时，“首页”“上一页”“下一页”“尾页”均置为disabled状态，总页数为1，input设为只读只显示1不予编辑
		 * 第二：当这列表大于一页的时候，初始化时“首页”“上一页”置为disabled状态，“下一页”“尾页”为able状态
		 * 总结：初始化时，无论总页数多少，“首页”“上一页”都是disabled，当列表的总页数大于1时“下一页”“尾页”为able状态
		 * 注意：由于input的type属性是一个只读属性，不能修改，所以只能另加一个type=“text”的input用于总页数小于等于1，input不予编辑的情况
		 * 页面默认时显示type为num的属性，只有当页面总数小于等于1时才显示type为text的input
		 * */
		$("#indexPage").attr("href","javascript:void(0);").addClass("disabled");//无论总页数多少，“首页”“上一页”都是disabled
		$("#prePage").attr("href","javascript:void(0);").addClass("disabled");//无论总页数多少，“首页”“上一页”都是disabled
		
		var totalPageValue=Math.ceil(parseInt($("#pageTotal").attr("value"))/10);//总页数
		var currentPageValue=parseInt($("#currentPage").attr("value"));
		$("#nowPage_num").attr("value",currentPageValue);//当前页置为1
		$("#nowPage_text").attr("value",currentPageValue);//当前页置为1
				
		if(totalPageValue<=1){//当列表的总页数小于等于1时，“下一页”“尾页”均置为disabled状态
			$("#nextPage").attr("href","javascript:void(0);").addClass("disabled");
			$("#lastPage").attr("href","javascript:void(0);").addClass("disabled");
			$("#totalPage").html("1");//总页数置为1
			$("#nowPage_num").hide();
			$("#nowPage_text").show();			
		}else{
			
			$("#totalPage").html(totalPageValue);
		}
		
	};
	newPageing.prototype.goFirstPage=function(){//“首页”按钮点击函数
		/*
		 * 点击“首页”回到第一页
		 * 如果当前页在第一页，此按钮disabled
		 * */
		var _this=this;
		var crrentPage=parseInt($("#currentPage").attr("value"));//当前页
		if(crrentPage==1){//如果当前页在第一页，此按钮disabled
			$("#indexPage").attr("href","javascript:void(0);").addClass("disabled");
		}else{
			$("#indexPage").removeClass("disabled");
			var aHref="";
			var url = location.href; 
			var orderBy="";
			var keyWord="";
			var group0="";
			var group1="";
			var status="";
			var shopid="";
			var currentGroup="";
			var zonegroup="";
			var zoneid="";
			if(url.indexOf("?")>0){
				group0=U.getUrlParam('group0');
				group1 = U.getUrlParam('group1');
				orderBy=U.getUrlParam('orderBy');
				keyWord=U.getUrlParam('keyWord');
				status=U.getUrlParam('status');
				shopid=U.getUrlParam('shopid');
				zonegroup=U.getUrlParam('zonegroup');
				zoneid=U.getUrlParam('zoneid');
				if(group1) {
					currentGroup = '&group0=' + group0 + '&group1=' + group1;
		   		} else if(group0) {
					currentGroup = '&group0=' + group0;
		   		}
				
				if(status!=null&&status!=""){
					url = url.substring(0,url.indexOf("?"))+"@status="+status;
				}else if(shopid!=null&&shopid!=""){
					url = url.substring(0,url.indexOf("?"))+"@shopid="+shopid;
				}else{
					url = url.substring(0,url.indexOf("?"))+"?";				
				} 
				
				if(shopid!=null&&shopid!=""){//在达人页要做特殊处理
					/*达人页面在翻页时要带上选服选区的信息*/
					if(zonegroup!=null&&zonegroup!=""){
						aHref=url+"&"+"zonegroup="+zonegroup+"&keyWord="+keyWord+"&"+"orderBy="+orderBy+"&page=1";
						if(zoneid!=null&&zoneid!=""){
							aHref=url+"&"+"zonegroup="+zonegroup+"&zoneid="
							+zoneid+"&keyWord="+keyWord+"&"+"orderBy="+orderBy+"&page=1";
						}
					}else{
						aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="+orderBy+"&page=1";
					}
				}else{
					aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="+orderBy+"&page=1";
				}
				
				
				
			}else{
				aHref=url+"@page=1";
			}
			$("#indexPage").attr("href",aHref);
		}
	};
	newPageing.prototype.goLastPage=function(){
		/*
		 * 点击“尾页”回到最后一页
		 * 如果当前页在最后一页，此按钮disabled
		 * */
		var _this=this;
		var crrentPage=parseInt($("#currentPage").attr("value"));//当前页
		var totalPage=Math.ceil(parseInt($("#pageTotal").attr("value"))/10);//分页总数
		var sTotalPage=Math.ceil(parseInt($("#pageTotal").attr("value"))/10).toString();//分页总数
		if(crrentPage==totalPage||totalPage==0){
			$("#lastPage").attr("href","javascript:void(0);").addClass("disabled");
		}else{
			$("#lastPage").removeClass("disabled");
			var aHref="";
			var url = location.href; 
			var orderBy="";
			var keyWord="";
			var group0="";
			var group1="";
			var status="";
			var shopid="";
			var currentGroup="";
			var zonegroup="";
			var zoneid="";
			if(url.indexOf("?")>0){
				group0=U.getUrlParam('group0');
				group1 = U.getUrlParam('group1');
				orderBy=U.getUrlParam('orderBy');
				keyWord=U.getUrlParam('keyWord');
				status=U.getUrlParam('status');
				shopid=U.getUrlParam('shopid');
				zonegroup=U.getUrlParam('zonegroup');
				zoneid=U.getUrlParam('zoneid');
				if(group1) {
					currentGroup = '&group0=' + group0 + '&group1=' + group1;
		   		} else if(group0) {
					currentGroup = '&group0=' + group0;
		   		}
				
				if(status!=null&&status!=""){
					url = url.substring(0,url.indexOf("?"))+"@status="+status;
				}else if(shopid!=null&&shopid!=""){
					url = url.substring(0,url.indexOf("?"))+"@shopid="+shopid;
				}else{
					url = url.substring(0,url.indexOf("?"))+"?";				
				}
				if(shopid!=null&&shopid!=""){//在达人页要做特殊处理
					/*达人页面在翻页时要带上选服选区的信息*/
					if(zonegroup!=null&&zonegroup!=""){
						aHref=url+"&"+"zonegroup="+zonegroup+"&keyWord="+keyWord+"&"+"orderBy="+orderBy+"&page="+sTotalPage;
						if(zoneid!=null&&zoneid!=""){
							aHref=url+"&"+"zonegroup="+zonegroup+"&zoneid="
							+zoneid+"&keyWord="+keyWord+"&"+"orderBy="+orderBy+"&page="+sTotalPage;
						}
					}else{
						aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="+orderBy+"&page="+sTotalPage;
					}
				}else{
					aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="+orderBy+"&page="+sTotalPage;
				}
			}else{
				aHref=url+"?page="+sTotalPage;
			}
			$("#lastPage").attr("href",aHref);
		}
		
	};
	newPageing.prototype.goPrevPage=function(){//“上一页”按钮点击操作
		/*
		 * 点击“上一页”跳转到前面一页，input的值减1，如果现在所处的位置为第一页的话，该按钮处于未激活状态
		 * */
		var _this=this;
		var crrentPage=parseInt($("#currentPage").attr("value"));//当前页
		if(crrentPage==1){//如果现在所处位置为第一页的话，该按钮处于未激活状态
			$("#prePage").attr("href","javascript:void(0);").addClass("disabled");
		}else{
			$("#prePage").removeClass("disabled");
			var aHref="";
			var url = location.href; 
			var orderBy="";
			var keyWord="";
			var group0="";
			var group1="";
			var status="";
			var shopid="";
			var currentGroup="";
			var zonegroup="";
			var zoneid="";
			if(url.indexOf("?")>0){
				group0=U.getUrlParam('group0');
				group1 = U.getUrlParam('group1');
				orderBy=U.getUrlParam('orderBy');
				keyWord=U.getUrlParam('keyWord');
				status=U.getUrlParam('status');
				shopid=U.getUrlParam('shopid');
				zonegroup=U.getUrlParam('zonegroup');
				zoneid=U.getUrlParam('zoneid');
				if(group1) {
					currentGroup = '&group0=' + group0 + '&group1=' + group1;
		   		} else if(group0) {
					currentGroup = '&group0=' + group0;
		   		}
				
				if(status!=null&&status!=""){
					url = url.substring(0,url.indexOf("?"))+"@status="+status;
				}else if(shopid!=null&&shopid!=""){
					url = url.substring(0,url.indexOf("?"))+"@shopid="+shopid;
				}else{
					url = url.substring(0,url.indexOf("?"))+"?";				
				}
				if(shopid!=null&&shopid!=""){//在达人页要做特殊处理
					/*达人页面在翻页时要带上选服选区的信息*/
					if(zonegroup!=null&&zonegroup!=""){
						aHref=url+"&"+"zonegroup="+zonegroup+"&keyWord="
						+keyWord+"&"+"orderBy="+orderBy+"&page="+(crrentPage-1).toString();
						if(zoneid!=null&&zoneid!=""){
							aHref=url+"&"+"zonegroup="+zonegroup+"&zoneid="
							+zoneid+"&keyWord="+keyWord+"&"+"orderBy="
							+orderBy+"&page="+(crrentPage-1).toString();
						}
					}else{
						aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="
						+orderBy+"&page="+(crrentPage-1).toString();
					}
				}else{
					aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="
					+orderBy+"&page="+(crrentPage-1).toString();
				}
				//aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="+orderBy+"&page="+(crrentPage-1).toString();
			}else{
				aHref=url+"?page="+(crrentPage-1).toString();
			}
			$("#prePage").attr("href",aHref);
		}
	};
	newPageing.prototype.goNextPage=function(){
		/*
		 * 点击“下一页”按钮进行跳转，如果现在的位置为最后一页，该按钮处于未激活状态
		 * */
		var _this=this;
		var crrentPage=parseInt($("#currentPage").attr("value"));//当前页
		var totalPage=Math.ceil(parseInt($("#pageTotal").attr("value"))/10);//分页总数
		var sTotalPage=Math.ceil(parseInt($("#pageTotal").attr("value"))/10).toString();//分页总数
		if(crrentPage==totalPage||totalPage==0){
			$("#nextPage").attr("href","javascript:void(0);").addClass("disabled");
		}else{
			$("#nextPage").removeClass("disabled");
			var aHref="";
			var url = location.href; 
			var orderBy="";
			var keyWord="";
			var group0="";
			var group1="";
			var status="";
			var shopid="";
			var currentGroup="";
			var zonegroup="";
			var zoneid="";
			if(url.indexOf("?")>0){
				group0=U.getUrlParam('group0');
				group1 = U.getUrlParam('group1');
				orderBy=U.getUrlParam('orderBy');
				keyWord=U.getUrlParam('keyWord');
				status=U.getUrlParam('status');
				shopid=U.getUrlParam('shopid');
				zonegroup=U.getUrlParam('zonegroup');
				zoneid=U.getUrlParam('zoneid');
				if(group1) {
					currentGroup = '&group0=' + group0 + '&group1=' + group1;
		   		} else if(group0) {
					currentGroup = '&group0=' + group0;
		   		}
				
				if(status!=null&&status!=""){
					url = url.substring(0,url.indexOf("?"))+"@status="+status;
				}else if(shopid!=null&&shopid!=""){
					url = url.substring(0,url.indexOf("?"))+"@shopid="+shopid;
				}else{
					url = url.substring(0,url.indexOf("?"))+"?";				
				}
				
				if(shopid!=null&&shopid!=""){//在达人页要做特殊处理
					/*达人页面在翻页时要带上选服选区的信息*/
					if(zonegroup!=null&&zonegroup!=""){
						aHref=url+"&"+"zonegroup="+zonegroup+"&keyWord="+keyWord
						+"&"+"orderBy="+orderBy+"&page="+(crrentPage+1).toString();
						if(zoneid!=null&&zoneid!=""){
							aHref=url+"&"+"zonegroup="+zonegroup+"&zoneid="
							+zoneid+"&keyWord="+keyWord+"&"+"orderBy="
							+orderBy+"&page="+(crrentPage+1).toString();
						}
					}else{
						aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"
						+"orderBy="+orderBy+"&page="+(crrentPage+1).toString();
					}
				}else{
					aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"
					+"orderBy="+orderBy+"&page="+(crrentPage+1).toString();
				}
				//aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="+orderBy+"&page="+(crrentPage+1).toString();
			}else{
				aHref=url+"?page="+(crrentPage+1).toString();
			}
			$("#nextPage").attr("href",aHref);
		}
	};
	newPageing.prototype.inputGoPage=function(){
		/*
		 * 当input失去焦点时，进行页面跳转，input中只能输入大于等于1的整数，输入非法数据页面不进行跳转
		 * 如果输入的数据大于页面总数，直接跳转到最后一页
		 */
		var _this=this;
		$("#nowPage_num").blur(function(){
			var oNumCheck=new numCheck();
			var inputPageValue=$(this).attr("value");
			var int_inputPageValue=parseInt($(this).attr("value"));
			var intFlag=oNumCheck.check_integer(inputPageValue);
			var totalPage=Math.ceil(parseInt($("#pageTotal").attr("value"))/10);//分页总数
			var sTotalPage=Math.ceil(parseInt($("#pageTotal").attr("value"))/10).toString();//分页总数
			if(intFlag==false){
				return false;//输入非法数据页面不进行跳转
			}else if(int_inputPageValue>totalPage){
				var aHref="";
				var url = location.href; 
				var orderBy="";
				var keyWord="";
				var group0="";
				var group1="";
				var status="";
				var shopid="";
				var currentGroup="";
				var zonegroup="";
				var zoneid="";
				if(url.indexOf("?")>0){
					group0=U.getUrlParam('group0');
					group1 = U.getUrlParam('group1');
					orderBy=U.getUrlParam('orderBy');
					keyWord=U.getUrlParam('keyWord');
					status=U.getUrlParam('status');
					shopid=U.getUrlParam('shopid');
					zonegroup=U.getUrlParam('zonegroup');
					zoneid=U.getUrlParam('zoneid');
					if(group1) {
						currentGroup = '&group0=' + group0 + '&group1=' + group1;
			   		} else if(group0) {
						currentGroup = '&group0=' + group0;
			   		}
					
					if(status!=null&&status!=""){
						url = url.substring(0,url.indexOf("?"))+"@status="+status;
					}else if(shopid!=null&&shopid!=""){
						url = url.substring(0,url.indexOf("?"))+"@shopid="+shopid;
					}else{
						url = url.substring(0,url.indexOf("?"))+"?";				
					}
					
					if(shopid!=null&&shopid!=""){//在达人页要做特殊处理
						/*达人页面在翻页时要带上选服选区的信息*/
						if(zonegroup!=null&&zonegroup!=""){
							aHref=url+"&"+"zonegroup="+zonegroup+"&keyWord="+keyWord
							+"&"+"orderBy="+orderBy+"&page="+sTotalPage;
							if(zoneid!=null&&zoneid!=""){
								aHref=url+"&"+"zonegroup="+zonegroup+"&zoneid="
								+zoneid+"&keyWord="+keyWord+"&"+"orderBy="
								+orderBy+"&page="+sTotalPage;
							}
						}else{
							aHref=url+"&"+"keyWord="+keyWord+currentGroup
							+"&"+"orderBy="+orderBy+"&page="+sTotalPage;
						}
					}else{
						aHref=url+"&"+"keyWord="+keyWord+currentGroup
						+"&"+"orderBy="+orderBy+"&page="+sTotalPage;
					}
					//aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="+orderBy+"&page="+sTotalPage;
				}else{
					aHref=url+"?page="+sTotalPage;
				}
				location.href=aHref;
			}else{
				var aHref="";
				var url = location.href; 
				var orderBy="";
				var keyWord="";
				var group0="";
				var group1="";
				var status="";
				var shopid="";
				var currentGroup="";
				var zonegroup="";
				var zoneid="";
				if(url.indexOf("?")>0){
					group0=U.getUrlParam('group0');
					group1 = U.getUrlParam('group1');
					orderBy=U.getUrlParam('orderBy');
					keyWord=U.getUrlParam('keyWord');
					status=U.getUrlParam('status');
					shopid=U.getUrlParam('shopid');
					zonegroup=U.getUrlParam('zonegroup');
					zoneid=U.getUrlParam('zoneid');
					if(group1) {
						currentGroup = '&group0=' + group0 + '&group1=' + group1;
			   		} else if(group0) {
						currentGroup = '&group0=' + group0;
			   		}
					
					if(status!=null&&status!=""){
						url = url.substring(0,url.indexOf("?"))+"@status="+status;
					}else if(shopid!=null&&shopid!=""){
						url = url.substring(0,url.indexOf("?"))+"@shopid="+shopid;
					}else{
						url = url.substring(0,url.indexOf("?"))+"?";				
					}
					
					if(shopid!=null&&shopid!=""){//在达人页要做特殊处理
						/*达人页面在翻页时要带上选服选区的信息*/
						if(zonegroup!=null&&zonegroup!=""){
							aHref=url+"&"+"zonegroup="+zonegroup+"&keyWord="+keyWord+"&"
							+"orderBy="+orderBy+"&page="+inputPageValue;
							if(zoneid!=null&&zoneid!=""){
								aHref=url+"&"+"zonegroup="+zonegroup+"&zoneid="
								+zoneid+"&keyWord="+keyWord+"&"+"orderBy="+orderBy
								+"&page="+inputPageValue;
							}
						}else{
							aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"
							+"orderBy="+orderBy+"&page="+inputPageValue;
						}
					}else{
						aHref=url+"&"+"keyWord="+keyWord+currentGroup
						+"&"+"orderBy="+orderBy+"&page="+inputPageValue;
					}
					//aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="+orderBy+"&page="+inputPageValue;
				}else{
					aHref=url+"?page="+inputPageValue;
				}
				location.href=aHref;
			}
			
		});
	};
	//分页操作_新_end
	
	//分页操作_begin
	var pagIng=function(currentPageInputId,totalPageInputId,prevId,nextId,curId,totalId,pageItemNum){
		this.currentPageInputId=currentPageInputId;
		this.totalPageInputId=totalPageInputId;
		this.prevId=prevId;
		this.nextId=nextId;
		this.curId=curId;
		this.totalId=totalId;
		this.pageItemNum=pageItemNum;
	};
	pagIng.prototype.pageInit=function(){
		var _this=this;
		var currentPageValue=$("#"+_this.currentPageInputId).attr("value");
		$("#"+_this.curId).html(currentPageValue);
		var totalItemValue=parseFloat($("#"+_this.totalPageInputId).attr("value"));
		var totalPageValue=Math.ceil(totalItemValue/_this.pageItemNum);
		if(totalPageValue!=0){
			$("#"+_this.totalId).html(totalPageValue);
		}else{
			$("#"+_this.totalId).html(1);
			$("#"+_this.nextId).attr("href","javascript:void(0);");
			$("#"+_this.nextId).attr("style","color: #999999");
		}
		
		if(currentPageValue=="1"){
			$("#"+_this.prevId).attr("href","javascript:void(0);");
			$("#"+_this.prevId).attr("style","color: #999999");
		}
		if(currentPageValue==totalPageValue){
			$("#"+_this.nextId).attr("style","color: #999999");
		}
		
	};
	pagIng.prototype.goPrePage=function(){
		var _this=this;
		var url = location.href; 
		var orderBy="";
		var keyWord="";
		var currentGroup="";
		var status="";
		var shopid="";
		if(url.indexOf("?")>0){
			var group0 = U.getUrlParam('group0');
  			var group1 = U.getUrlParam('group1');
  			orderBy=U.getUrlParam('orderBy');
  			keyWord=U.getUrlParam('keyWord');
  			status=U.getUrlParam('status');
  			shopid=U.getUrlParam('shopid');
			if(group1) {
				currentGroup = '&group0=' + group0 + '&group1=' + group1;
	   		} else if(group0) {
				currentGroup = '&group0=' + group0;
	   		}
		}
		if(url.indexOf("?") > 0) {
			if(status!=null&&status!=""){
				url = url.substring(0,url.indexOf("?"))+"@status="+status;
			}else if(shopid!=null&&shopid!=""){
				url = url.substring(0,url.indexOf("?"))+"@shopid="+shopid;
			}else{
				url = url.substring(0,url.indexOf("?"));				
			} 			  			
   		}
		var currentPageValue=parseFloat($("#"+_this.currentPageInputId).attr("value"));
		var totalItemValue=parseFloat($("#"+_this.totalPageInputId).attr("value"));
		var totalPageValue=Math.ceil(totalItemValue/_this.pageItemNum);
		var aHref="";
		if(currentPageValue!=1){
			if(url.indexOf("?")!=-1){
				aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="+orderBy+"&page="+(currentPageValue-1).toString();
			}else{
				aHref=url+"?"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="+orderBy+"&page="+(currentPageValue-1).toString();
			}
			
		}else{
			aHref="javascript:void(0);";
		}
		
		$("#"+_this.prevId).attr("href",aHref);
	};
	pagIng.prototype.goNextPage=function(){
		var _this=this;
		var url = location.href; 
		var orderBy="";
		var keyWord="";
		var currentGroup="";
		var status="";
		var shopid="";
		if(url.indexOf("?")>0){
			var group0 = U.getUrlParam('group0');
  			var group1 = U.getUrlParam('group1');
  			orderBy=U.getUrlParam('orderBy');
  			keyWord=U.getUrlParam('keyWord');
  			status=U.getUrlParam('status');
  			shopid=U.getUrlParam('shopid');
			if(group1) {
				currentGroup = '&group0=' + group0 + '&group1=' + group1;
	   		} else if(group0) {
				currentGroup = '&group0=' + group0;
	   		}
		}
		if(url.indexOf("?") > 0) {
			if(status!=null&&status!=""){
				url = url.substring(0,url.indexOf("?"))+"@status="+status;
			}else if(shopid!=null&&shopid!=""){
				url = url.substring(0,url.indexOf("?"))+"@shopid="+shopid;
			}else{
				url = url.substring(0,url.indexOf("?"));				
			} 	
   		}
		var currentPageValue=parseFloat($("#"+_this.currentPageInputId).attr("value"));
		var totalItemValue=parseFloat($("#"+_this.totalPageInputId).attr("value"));
		var totalPageValue=Math.ceil(totalItemValue/_this.pageItemNum);
		var aHref="";
		if(currentPageValue!=totalPageValue){
			if(url.indexOf("?")!=-1){
				aHref=url+"&"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="+orderBy+"&page="+(currentPageValue+1).toString();
			}else{
				aHref=url+"?"+"keyWord="+keyWord+currentGroup+"&"+"orderBy="+orderBy+"&page="+(currentPageValue+1).toString();
			}
			
		}else{
			aHref="javascript:void(0);";
		}
		if(totalPageValue==0){
			aHref="javascript:void(0);";
		}
		
		$("#"+_this.nextId).attr("href",aHref);
	};
	//分页操作_end
	
	//分类操作_begin
	var systematization=function(sysId,sysTreeId,maskId,
		firstLevelFlagClass,heightLightClass,secondLevelClass,secondLevelContainClass,
		sysListHeightTempId,allTypeId,treeLIPClass){
		this.sysId=sysId;//分类按钮ID
		this.maskId=maskId;//遮罩ID
		this.sysTreeId=sysTreeId;//分类ID
		this.firstLevelFlagClass=firstLevelFlagClass;//一级分类标识样式
		this.heightLightClass=heightLightClass;//高亮样式
		this.secondLevelClass=secondLevelClass;//二级分类标识样式
		this.secondLevelContainClass=secondLevelContainClass;//二级分类的父标签标识样式
		this.sysListHeightTempId=sysListHeightTempId;//分类列表的ul的外层div的id,用于计算列表项的高度
		this.allTypeId=allTypeId;//全部分类Id
		this.treeLIPClass=treeLIPClass;
	};
	systematization.prototype.sysInit=function(){//列表初始化操作
		var _this=this;
		
		var url = location.href; 
		if(url.indexOf("buy.gsp")>-1){//分类操作只存在于”我要买“和”达人页面“，
			$("#a_allType").attr("href","buy.gsp");//”我要买“页面点击”全部分类“，跳转回buy.gsp页面
		}else if(url.indexOf("shopid")>-1){
			var tempurl=url.substring(0,url.indexOf("?"))+"@shopid="+U.getUrlParam('shopid');
			$("#a_allType").attr("href",tempurl);//”达人“页面点击”全部分类“，跳回”达人“页面
		}
		var group0="";
		var group1="";
		var keyword="";
		var page="";
		var orderBy="";
		if(url.indexOf("?")!=-1){
			group0=U.getUrlParam('group0');//通过地址栏url获取一级分类信息的状况
			group1=U.getUrlParam('group1');//通过地址栏url获取二级分类信息的状况
			orderBy=U.getUrlParam('orderBy');
			page=U.getUrlParam('page');
		}
		if(group0!=null&&group0!=""){//当页面的地址栏中的信息有一级分类但是没有二级分类的信息的情况下
			if(group1==""||group1==null){//以下代码，当用于选择了一级分类的某一项之后，页面进行跳转，跳转完毕后再次显示有关分类的容器以及遮罩，目的是为了方便用户进行二级细类的选择
				$("#"+_this.sysTreeId).find("[firstLevel='"+group0+"']").show();//”分类“容器中显示该一级分类的详细信息
				if(orderBy==""&&page==""){
					var liPHeight=$(".property").eq(0).height();
					var liPSize=$("#"+_this.sysTreeId).find("[firstLevel='"+group0+"']").find("."+_this.treeLIPClass).size();
					var liPTotalHeigh=liPHeight*liPSize;
					var liSize=$("#J_select").find("li").size();
					var liTotalHeight=liSize*42;
					var allTypeHeight=$("#"+_this.allTypeId).height();
					var sysTreeHeight=liPTotalHeigh+liTotalHeight+allTypeHeight+70;//以上代码用于设定分类容器的高度,计算方法与页面布局有关	
					$("#"+_this.sysTreeId).height(sysTreeHeight).show();//显示”分类“			
					$("#"+_this.sysTreeId).animate({right:"0px"},"500");
					var mianContainHeight=$("#mainContent").height();
					if(mianContainHeight>=sysTreeHeight+120){
						$("#"+_this.maskId).height(mianContainHeight);
					}else{
						$("#"+_this.maskId).height(sysTreeHeight+120);
					}//以上代码用于设定遮罩的高度
					$("#"+_this.maskId).show();//遮罩显示
				}
				
				
			}else{//当页面的地址栏中的信息有二级分类详情时（有二级分类肯定有一级分类）
				$("#"+_this.sysTreeId).find("."+_this.secondLevelClass).removeClass(_this.heightLightClass);//
				$("#"+_this.sysTreeId).find("p[title='"+group1+"']").addClass(_this.heightLightClass);
				var secondLevelParents=$("#"+_this.sysTreeId).find("p[title='"+group1+"']").parent("."+_this.secondLevelContainClass);
				if(secondLevelParents.size()>1){
					secondLevelParents.each(function(){
						if($(this).attr("firstlevel")==group0){
							$(this).show();
						}
					});
				}else{
					secondLevelParents.show();
				}
				//.show();
			}
		}
	};
	systematization.prototype.showHide=function(){
		var _this=this;
		$("#"+_this.sysId).click(function(){//点击“全部分类”按钮，分类，遮罩显示			
			$("#"+_this.sysTreeId).show();
			var listHeight=$("#"+_this.sysListHeightTempId).height();
			var allTypeHeight=$("#"+_this.allTypeId).height();
			var listTreeHeight=listHeight+allTypeHeight+70;
			$("#"+_this.sysTreeId).height(listTreeHeight);
			$("#"+_this.sysTreeId).animate({right:"0px"},"500");
			var mianContainHeight=$("#mainContent").height();
			if(mianContainHeight>=listTreeHeight+120){
				$("#"+_this.maskId).height(mianContainHeight);
			}else{
				$("#"+_this.maskId).height(listTreeHeight+120);
			}
			$("#"+_this.maskId).show();
			
		});
		$("#"+_this.maskId).click(function(){//点击遮罩部分，分类与遮罩隐藏
			$("#"+_this.sysTreeId).animate({right:"-190px"},"500");
			setTimeout('$("#"+'+_this.sysTreeId+').hide()',500);
			$(this).hide();
		});
	};
	systematization.prototype.sysControl=function(){
		var _this=this;
		var url = location.href; 
		var orderBy="";
		var shopid="";
		if(url.indexOf("?")!=-1){
			orderBy=U.getUrlParam('orderBy');
			shopid=U.getUrlParam('shopid');
		}else{
			orderBy="";//如果地址中没有参数，按照默认顺序对结果进行排序
		}
		
		$("#"+_this.sysTreeId).find("."+_this.firstLevelFlagClass).each(function(){//点击一级目录时，进行查询操作
			$(this).click(function(){
				if(url.indexOf("?") > 0) {
		   			url = url.substring(0,url.indexOf("?"));
		   		}
				var currentGroup=$(this).attr("title");
				if(shopid!=""&&shopid!=null){
					url=url+"@shopid="+shopid+"&group0="+currentGroup+"&"+"orderBy="+orderBy;
				}else{
					url=url+"?"+"group0="+currentGroup+"&"+"orderBy="+orderBy;
				}
				
				location.href=url;
			});
		});
		
		$("#"+_this.sysTreeId).find("."+_this.secondLevelClass).each(function(){
			$(this).click(function(){
				var shopid="";
				if(url.indexOf("?") > 0) {
					shopid=U.getUrlParam('shopid');
		   			url = url.substring(0,url.indexOf("?"));
		   		}
				var currentGroup0=$(this).parent("."+_this.secondLevelContainClass).attr("firstLevel");
				var currentGroup1=$(this).attr("title");
				if(shopid!=""&&shopid!=null){
					url=url+"@shopid="+shopid+"&group0="+currentGroup0+"&"+"group1="+currentGroup1+"&"+"orderBy="+orderBy;
				}else{
					url=url+"?"+"group0="+currentGroup0+"&"+"group1="+currentGroup1+"&"+"orderBy="+orderBy;
				}
				
				
				location.href=url;
			});
		});
		
	};
	
	systematization.prototype.typeFlagFunction=function(){
		var group="";
		var url=location.href;
		if(url.indexOf("?")!=-1){
			var group0=U.getUrlParam('group0');
			var group1=U.getUrlParam('group1');
			if(group1!=""&&group1!=null){
				$("#sys_span").find("font").html(group1);
			}else if(group0!=""&&group0!=null){
				$("#sys_span").find("font").html(group0);
			}
		}
	};
	
	//分类标记_end
	
	//顶部Tab切换操作_begin
		var tabSwich=function(tabFirstLevelId,tabBuySecondLevelId,tabSaleSeconLevelId){
			this.tabFirstLevelId=tabFirstLevelId;//一级Tab容器Id
			this.tabBuySecondLevelId=tabBuySecondLevelId;//"我要买"二级tab的Id
			this.tabSaleSeconLevelId=tabSaleSeconLevelId;//“我要卖”二级tab的Id
		};
		tabSwich.prototype.tabFirstLevelStatuControl=function(){//一级Tab状态切换
			var _this=this;
			var url=location.href;
			$("#"+_this.tabFirstLevelId).find("a").attr("style","color:#000000;");
			if(url.indexOf("sale")!=-1){
				$("#"+_this.tabFirstLevelId).find("li[title='sale']").addClass("curr last");
				$("#"+_this.tabFirstLevelId).find("li[title='sale']").find("a").attr("style","color:#106FB3;");
				$("#"+_this.tabSaleSeconLevelId).show();
			}else if(url.indexOf("attic")!=-1||url.indexOf("specify")!=-1){//
				$("#"+_this.tabFirstLevelId).find("li[title='buy']").addClass("curr first");
				$("#"+_this.tabFirstLevelId).find("li[title='buy']").find("a").attr("style","color:#106FB3;");
				$("#"+_this.tabBuySecondLevelId).show();
			}
		};
		tabSwich.prototype.tabBuySecondLevelStatuControl=function(){//“我要买”二级Tab状态切换
			var _this=this;
			var url=location.href;
			$("#"+_this.tabBuySecondLevelId).find('a').attr("style","color:#000000;");
			if(url.indexOf("specify")!=-1&&url.indexOf("showSpecify")<0){
				$("#"+_this.tabBuySecondLevelId).find("li[title='buy_specify']").addClass("curr");
				$("#"+_this.tabBuySecondLevelId).find("li[title='buy_specify']").find("a").attr("style","color:#FFFFFF;");
			}else if(url.indexOf("attic")!=-1&&url.indexOf("paid")!=-1){
				$("#"+_this.tabBuySecondLevelId).find("li[title='buy_paid']").addClass("curr");
				$("#"+_this.tabBuySecondLevelId).find("li[title='buy_paid']").find("a").attr("style","color:#FFFFFF;");
			}
		};
		tabSwich.prototype.tabSaleSecondLevelStatuControl=function(){//“我要卖”二级Tab状态切换
			var _this=this;
			var url=location.href;
			$("#"+_this.tabSaleSeconLevelId).find("a").attr("style","color:#000000;");
			if(url.indexOf("sale")!=-1){
				if(url.indexOf("post")!=-1){
					$("#"+_this.tabSaleSeconLevelId).find("li[title='sale_post']").addClass("curr");
					$("#"+_this.tabSaleSeconLevelId).find("li[title='sale_post']").find("a").attr("style","color:#FFFFFF;");
				}
				if(url.indexOf("up")!=-1){
					$("#"+_this.tabSaleSeconLevelId).find("li[title='sale_up']").addClass("curr");
					$("#"+_this.tabSaleSeconLevelId).find("li[title='sale_up']").find("a").attr("style","color:#FFFFFF;");
				}
				if(url.indexOf("book")!=-1){
					$("#"+_this.tabSaleSeconLevelId).find("li[title='sale_booked']").addClass("curr");
					$("#"+_this.tabSaleSeconLevelId).find("li[title='sale_booked']").find("a").attr("style","color:#FFFFFF;");
				}
				if(url.indexOf("pay")!=-1){
					$("#"+_this.tabSaleSeconLevelId).find("li[title='sale_paid']").addClass("curr");
					$("#"+_this.tabSaleSeconLevelId).find("li[title='sale_paid']").find("a").attr("style","color:#FFFFFF;");
				}
			}
		};
	//顶部Tab切换操作_end
	
	//弹出框_beigin
	var Pop=function(titleText, contentText, containerId, func){
		this.titleText=titleText;
		this.contentText=contentText;
		this.containerId=containerId;
		this.func=func;
	};
	
	Pop.prototype.popConfirm=function(){
		var _this=this;
		var popHtml='<div class="content2"><h3>'
			+_this.titleText+'<button data-role="none" class="close fr" id="closeButton">X</button></h3><ul><li style="padding-bottom:0px;"><p>'
			+_this.contentText+'</p></li><li>'+
			'<input id="popCancel" class="fl sub_btn3" type="submit" value="取消" style="width:45%; margin-right:2%; ">'
			+'<input id="popSure" class="fl sub_btn" type="submit" value="确定" style="width:45%;"></li></ul></div>';
		var func=_this.func;
		$("#"+_this.containerId).html(popHtml);
		$("#"+_this.containerId).show();
		var documentHeight=$("#mainContent").height();
		$("#leftmask2").height(documentHeight);
		$("#leftmask2").show();
		
		$("#popSure").click(function(){
			$("#leftmask2").hide();
			$("#"+_this.containerId).hide();
			func();
			return false;
		});
		
		$("#popCancel").click(function(){
			$("#leftmask2").hide();
			$("#"+_this.containerId).hide();
			return false;
		});
		
		$("#closeButton").click(function(){
			$("#leftmask2").hide();
			$("#"+_this.containerId).hide();
			return false;
		});

	};
	
	Pop.prototype.popAlert=function(){
		var _this=this;
		_this.titleText="来自寻宝天行的消息";
		var popHtml='<div class="content2"><h3>'
			+_this.titleText+'<button data-role="none" class="close fr" id="closeButton">X</button></h3><ul><li style="padding-bottom:0px;"><p>'
			+_this.contentText+'</p></li><li>'
			+'<input id="popSure" class="fl sub_btn_1" type="submit" value="确定" style="width:45%;margin-left:25%;"></li></ul></div>';
		var func=_this.func;
		$("#"+_this.containerId).html(popHtml);
		$("#"+_this.containerId).show();
		var documentHeight=$("#mainContent").height();
		$("#leftmask2").height(documentHeight);
		$("#leftmask2").show();
		$("#popSure").click(function(){
			$("#leftmask2").hide();
			$("#"+_this.containerId).hide();
			if(func){
				func();
			}		
			return false;
		});
		$("#closeButton").click(function(){
			$("#leftmask2").hide();
			$("#"+_this.containerId).hide();
			return false;
		});
	};
	//弹出框_end
	
	//登录判断_begin
	var isLogin=function(isLoginFlagId){
		this.isLoginFlagId=isLoginFlagId;
	};
	isLogin.prototype.isLoginJudge=function(){
		var _this=this;
		var isLogin=$("#"+_this.isLoginFlagId).attr("value");
		if(isLogin=="true"){
			$("a[href*='.do']").click(function(){
				var href = $(this).attr("href");
				var oPop=new Pop("请您登录","登录后才能进行该操作，您要登录吗？","popup",function() {location.href = href;});
				oPop.popConfirm();
				return false;
			});
		}
	};
	//登录判断_end
	
	//判断用户是否被封禁_begin
	var isForbid=function(forbidFlagId,forbidTextId){
		this.forbidFlagId=forbidFlagId;
		this.forbidTextId=forbidTextId;
	};
	isForbid.prototype.isForbidJudge=function(){
		var _this=this;
		var forbidStatu=$("#"+_this.forbidFlagId).attr("value");
		var forbidText=$("#"+_this.forbidTextId).attr("value").replace(/\\n/g, '<br>');
		
		if(forbidStatu=="true"){
			var oPop=new Pop("",forbidText,"popup",function() {$.post("confirmForbid.do");});
			oPop.popAlert();
		}
	};
	//判断用户是否被封禁_end
	
	//类似“我要买”→“指定卖给我”没有详细信息显示的列表项的操作_begin
	var listNoDetailControl=function(listContainId,evenClass,oddClass,moreId,showNum){
		this.listContainId=listContainId;//列表父级元素Id
		this.evenClass=evenClass;//偶数个元素的样式
		this.oddClass=oddClass;//奇数个元素的样式
		this.moreId=moreId;//“更多”按钮Id
		this.showNum=showNum;//每次显示的元素的个数
	};
	listNoDetailControl.prototype.listControl=function(){
		var _this=this;
		$("#"+_this.listContainId).find("li:odd").addClass(_this.oddClass);//为列表奇数个元素设置样式
		$("#"+_this.listContainId).find("li:even").addClass(_this.evenClass);//为列表偶数个元素设置样式
	};
	listNoDetailControl.prototype.MoreButonContrl=function(){
		var _this=this;
		var listItemSize=$("#"+_this.listContainId).find("li").size();
		if(listItemSize<=_this.showNum){//如果当前物品的个数小于等于预定义的每次显示的个数，“更多”按钮隐藏
			$("#"+_this.moreId).hide();
			$("#"+_this.moreId).parents("ul.moreButtonFlag").hide();
			$("#"+_this.listContainId).find("li").show();//显示全部的物品信息
		}else{
			$("#"+_this.moreId).show();////如果当前物品的个数大于预定义的每次显示的个数，“更多”按钮显示
			$("#"+_this.listContainId).find("li:lt("+_this.showNum+")").show();
		}
		var ModuleSize=Math.ceil(listItemSize/_this.showNum);//计算列表信息分为几块进行显示，showNum为每块显示几条
		var tempCount=1;
		$("#"+_this.moreId).click(function(){//“更多”按钮点击操作
			var showEnd=(tempCount+1)*_this.showNum;
			$("#"+_this.listContainId).find("li:lt("+showEnd+")").slideDown();
			if (tempCount + 1 == ModuleSize) {
				$("#" + _this.moreId).hide();
			} else {
				tempCount++;
			}
		});
	};
	//类似“我要买”→“指定卖给我”没有详细信息显示的列表项的操作_end
	
	//“我的购物车”页面→没有详细信息显示的列表项的操作_begin
	var atticListControl=function(listContainId,evenClass,oddClass,moreId,showNum){
		this.listContainId=listContainId;//列表父级元素Id
		this.evenClass=evenClass;//偶数个元素的样式
		this.oddClass=oddClass;//奇数个元素的样式
		this.moreId=moreId;//“更多”按钮Id
		this.showNum=showNum;//每次显示的元素的个数
	};
	atticListControl.prototype.listControl=function(){
		var _this=this;
		$("#"+_this.listContainId).find("div.list2_1:odd").addClass(_this.oddClass);//为列表奇数个元素设置样式
		$("#"+_this.listContainId).find("div.list2_1:even").addClass(_this.evenClass);//为列表偶数个元素设置样式
	};
	atticListControl.prototype.MoreButonContrl=function(){
		var _this=this;
		var listItemSize=$("#"+_this.listContainId).find("div.list2_1").size();
		if(listItemSize<=_this.showNum){//如果当前物品的个数小于等于预定义的每次显示的个数，“更多”按钮隐藏
			$("#"+_this.moreId).hide();
			$("#"+_this.listContainId).find("div.list2_1").show();//显示全部的物品信息
		}else{
			$("#"+_this.moreId).show();////如果当前物品的个数大于预定义的每次显示的个数，“更多”按钮显示
			$("#"+_this.listContainId).find("div.list2_1:lt("+_this.showNum+")").show();
		}
		var ModuleSize=Math.ceil(listItemSize/_this.showNum);//计算列表信息分为几块进行显示，showNum为每块显示几条
		var tempCount=1;
		$("#"+_this.moreId).click(function(){//“更多”按钮点击操作
			var showEnd=(tempCount+1)*_this.showNum;
			$("#"+_this.listContainId).find("div.list2_1:lt("+showEnd+")").slideDown();
			if (tempCount + 1 == ModuleSize) {
				$("#" + _this.moreId).hide();
			} else {
				tempCount++;
			}
		});
	};
	//“我的购物车”页面→没有详细信息显示的列表项的操作_end
	
	
	//详细页角色列表生成_begin
	var itemDetailRoleList=function(roleListId,roleDetailClass){
		this.roleListId=roleListId;
		this.roleDetailClass=roleDetailClass;
	};
	itemDetailRoleList.prototype.roleListResolve=function(){
		var _this=this;
		$("."+_this.roleDetailClass).each(function(){
			var array = $(this).html().split(",");
			var roleid = array[0];
			var roleName = array[1];
			var menpai = array[3];
			var grade = array[4];
			var gender = array[5];
			if(roleid && roleName && menpai && grade && gender) {
				$("select").append('<option grade="'+grade+'" value="'
						+roleid+'" name="'+roleName+'" gender="'
						+gender+'">'+roleName+'('+menpai
						+'-'+grade+'级-'+gender+')</option>');
			}
		});
	};
	//详细页角色列表生成_end
	
	//物品详细页“购买”按钮点击操作_begin
	var itemDetailBuyButton=function(buyButtonId,commonId,roleSelectId){
		this.buyButtonId=buyButtonId;//“购买”按钮的Id
		this.commonId=commonId;//带有商品号的隐藏input的Id值
		this.roleSelectId=roleSelectId;//角色选择列表的id值
	};
	itemDetailBuyButton.prototype.roleGender=function(){
		var _this=this;
		$("#"+_this.roleSelectId).change(function(){
			var isRoleTemp=$("#hiddenisROLE").attr("value");
			var isRole;
			if(isRoleTemp=="true"){
				isRole=true;
			}else{
				isRole=false;
			}
			 var gender=$(this).find("option:selected").attr("gender");
			 if(isRole=="true"){
				 var buyerGender=$("#roleXML").find("xml").find("basic").find("gender").attr("value");
				 if($.trim(gender)!=$.trim(buyerGender)){
					 var oPop = new Pop("", "当前角色性别与购买角色性别不一致！", "popup");
					 oPop.popAlert();
					 $($(this).find("option")[0]).attr("selected",true);
				 }
			 }			
		});
	};
	itemDetailBuyButton.prototype.buyButtonOperating=function(){
		var _this=this;
		$("#"+_this.buyButtonId).click(function(){
			var commonId=$("#"+_this.commonId).attr("value");//商品号
			var roleId=$("#"+_this.roleSelectId).val();//所选择的角色的Id
			var sellerNameValue=$("#hiddensellerName").attr("value");
			var returnFlag =false;
			var isRoleTemp=$("#hiddenisROLE").attr("value");
			var isRole;
			if(isRoleTemp=="true"){
				isRole=true;
			}else{
				isRole=false;
			}
			if(isRole){
				$("#"+_this.roleSelectId).find("option").each(function (){
					if($(this).attr("grade")>10){
						  var oPop = new Pop("", "账号下有大于10级的角色，不能再购买角色！", "popup");
						  oPop.popAlert();
						   returnFlag = true;
						   return false;
					}					
				});
				if(returnFlag){
					return;
				}
			}
			
			if(!roleId&&$("select").size()==1){//角色选择提醒
				var oPop=new Pop("","请选择一个角色","popup");
				oPop.popAlert();
				return;
			}
			var customer = $("select option:selected").attr("name");
			if(isRole && customer){
				var oPop = new Pop("来自寻宝天行提示消息", "重要提示：<br/>&nbsp;&nbsp;&nbsp;&nbsp;您<font style='display:inline' color=\"#FF6600\">"
						+customer+"</font>的包裹、仓库、宠物等物品将会被<font style='display:inline' color=\"#FF6600\">"
						+sellerNameValue+"</font>的物品覆盖，"+"请及时转移该角色包裹和仓库中贵重物品，"+
						"避免不必要的损失。请谨慎操作。", "popup", function() {
					$.ajax({
				    	type: "POST",
				    	dataType: "xml",
				   		url: "bookOneCommodity.do",
				   		data: {"commid": commonId, "roleid": roleId, "orderNum": "orderNum"},
				   		success: function(xml){
					   		var statusCode = $(xml).find('statusCode').text();
					   		var message = $(xml).find('message').text();
					   		var orderNum = $(xml).find('orderNum').text();
					   		if(statusCode=="200") {
					   			var oPop = new Pop("", message, "popup", function() {location.href = "prePay.do@orderNum="+orderNum;});
					   			oPop.popAlert();
					   		} else if(statusCode=='302'){
					   			var href = $(xml).find("redirectURL").text();
					   			var oPop = new Pop("请您登录", "登录后才能进行该操作，您要登录吗？", "popup", function() {location.href = href;});
					   			oPop.popConfirm();
					   		} else {
					   			var oPop=new Pop("",message,"popup");
					   			oPop.popAlert();
					   		}
				   		}	
					}); 
				});
				oPop.popConfirm();
				$('#popSure').text('继续');
				$('#popCancel').text('再考虑下');
			}else{
				$.ajax({
					type: "POST",
					dataType: "xml",
					url: "bookOneCommodity.do",
					data: {"commid": commonId, "roleid": roleId, "orderNum": "orderNum"},
					success: function(xml){
						var statusCode = $(xml).find("statusCode").text();
				   		var message = $(xml).find("message").text();
				   		var orderNum = $(xml).find("orderNum").text();
				   		if(statusCode=='200') {
				   			var oPop=new Pop("",message,"popup",function() {location.href = "prePay.do@orderNum="+orderNum;});
				   			oPop.popAlert();
				   		}else if(statusCode=='302'){
				   			var href = $(xml).find('redirectURL').text();
				   			var oPop=new Pop("请您登录","登录后才能进行该操作，您要登录吗？","popup",function() {location.href = href;});
							oPop.popConfirm();
				   		}else{
				   			var oPop=new Pop("",message,"popup");
				   			oPop.popAlert();
				   		}
					}
				});
			}		
		});
	};
	//物品详细页“购买”按钮点击操作_end
	
	//“我要卖”→“已上架”页面，“下架”按钮点击操作_begin
	var saleUpOffShell=function(offShellId){
		this.offShellId=offShellId;//“下架”按钮Id
	};
	saleUpOffShell.prototype.offShell=function(){
		var _this=this;
		$("."+_this.offShellId).each(function(){
			$(this).click(function(){
				var oPop = new Pop("商品下架", "您确定要将该商品下架？", "popup", function() {cancelUp();});
				oPop.popConfirm();
				var commid=$(this).parents("li").prev("input.commClass").attr("value");
				function cancelUp() {
		   			$.ajax({
		   		    	type: "POST",
		   		   		url: "cancelSaleUp.do",
		   		   		data: {"commid": commid},
		   		   		success: function(xml){
					   		var statusCode = $(xml).find("statusCode").text();
					   		var message = $(xml).find("message").text();
					   		if(statusCode=="200") {
					   			var oPop = new Pop("", message, "popup", function() {location.href = "sale.do@status=up";});
					   			oPop.popAlert();
					   		} else if(statusCode=="302"){
					   			var href = $(xml).find("redirectURL").text();
					   			var oPop = new Pop("请您登录", "登录后才能进行该操作，您要登录吗？", "popup", function() {location.href = href;});
					   			oPop.popConfirm();
					   		} else {
					   			var oPop=new Pop("",message,"popup");
					   			oPop.popAlert();
					   		}
				   		}	
		   			}); 
				}
			});
		});
	};
	//“我要卖”→“已上架”页面，“下架”按钮点击操作_end
	
	//“购物车”→“取消按钮操作”_begin
	var atticCancle=function(CancleButtonClass,commIdClass,orderNumFlagClass){
		this.CancleButtonClass=CancleButtonClass;
		this.commIdClass=commIdClass;
		this.orderNumFlagClass=orderNumFlagClass;
	};
	atticCancle.prototype.cancleContorl=function(){
		var _this=this;
		$("."+_this.CancleButtonClass).each(function(){
			$(this).click(function(){
				var commid=$(this).parents("div.list2_1").find("input."+_this.commIdClass).attr("value");
				var orderNum=$(this).parents("div.list2_1").find("input."+_this.orderNumFlagClass).attr("value");
				
				var oPop = new Pop("废除该订单", "您确定要废除该订单吗？", "popup", function() {cancelAction();});
				oPop.popConfirm();
				
				function cancelAction () {
					$.ajax({
						type: "POST",
						url: "cancelBook.do",
						data: {"commid": commid, "orderNum" : orderNum},
						success: function(xml){
							var statusCode = $(xml).find("statusCode").text();
					   		var message = $(xml).find("message").text();
					   		if(statusCode=="200") {
					   			var oPop = new Pop("", message, "popup", function() {location.href = "attic.do@status=unpaid";});
					   			oPop.popAlert();
					   		}else if(statusCode=="302"){
					   			var href = $(xml).find("redirectURL").text();
					   			var oPop = new Pop("请您登录", "登录后才能进行该操作，您要登录吗？", "popup", function() {location.href = href;});
					   			oPop.popConfirm();
					   		}else{
					   			var oPop=new Pop("",message,"popup");
					   			oPop.popAlert();
					   		}
						}
					});
				}
			});
		});
	};
	//“购物车”→“取消按钮操作”_end
		var atticPay=function(payButtonClass,orderNumFlagClass){
			this.payButtonClass=payButtonClass;
			this.orderNumFlagClass=orderNumFlagClass;
		};
		atticPay.prototype.payButtonClick=function(){
			var _this=this;
			$("."+_this.payButtonClass).each(function(){
				$(this).click(function(){
					var orderNum=$(this).parents("div.list2_1").find("input."+_this.orderNumFlagClass).attr("value");
					location.href = "prePay.do@orderNum="+orderNum;
				});
			});
		};
	//“购物车”→“支付按钮操作”_begin
		
	//达人页面→达人信息解析_begin
		var VIPInformation=function(vipNameId,vipLevelId,vipDesId,headIconId){
			this.vipNameId=vipNameId;//达人名称Id
			this.vipLevelId=vipLevelId;//达人等级→金牌 银牌 铜牌Id
			this.vipDesId=vipDesId;//达人描述Id
			this.headIconId=headIconId;//达人头像Id
		};
		VIPInformation.prototype.vipInfoShow=function(){
			var _this=this;
			var basePath=$("#basePathId").attr("value");
			
			var shopid = U.getUrlParam("shopid");
			 $.ajax({
				 type : "post",
				 url: basePath+"shopinfo.gsp",
				 async: true,
				 dataType:"xml",
				 data:{aid:10,shopid:shopid},
				 success: function (data){
					 var shopUserInfo = $(data).find("shopUserInfo");
					 var shopname = shopUserInfo.find("shopname").attr("value");
					 var description = shopUserInfo.find("description").attr("value");
					 var iconPath = shopUserInfo.find("iconPath").attr("value");
					 var score =  shopUserInfo.find("scoreGrade").attr("value");
					 var scoreImg = "";
					 if(score=="3"){
						 scoreImg='<img src="images/shop/gold-medal.gif" width="20" height="20">';
					 }else if(score=="2"){
						 scoreImg='<img src="images/shop/iron_medal.gif" width="20" height="20">';
					 }else if(score=="1"){
						 scoreImg='<img src="images/shop/copper_medal.gif" width="20" height="20">';
					 }else{
						 scoreImg="";
					 }
					 /*switch(score){
					 	case "3":scoreImg='<img src="images/shop/gold-medal.gif" width="20" height="20">';
					 	case "2":scoreImg='<img src="images/shop/iron_medal.gif" width="20" height="20">';
					 	case "1":scoreImg='<img src="images/shop/copper_medal.gif" width="20" height="20">';
					 	
					 	break;
					 }*/
					 $("#"+_this.vipLevelId).html(scoreImg);//达人等级→金牌 银牌 铜牌
					 $("#"+_this.vipNameId).html(shopname);//达人名称
					 $("#"+_this.vipDesId).html(description);//达人描述
					 
					 var darenInfomationHeight=$("#darenUserInformation").height();//达人描述部分的高度
						
					var headHeight=$("div.header").height();//头部的高度
					var darenTitleHeight=$("#darenTitleService").height()+10+2;//title部分的高度，“达人主页” 后面的10，是因为title部分有两个各上下5px的padding后面的2是因为上下各1px的border
					var darenSearchHeight=$("#darenSearchPanel").height()+10+2;//"搜索栏"部分的高度，后面10和2分别因为padding和border
					var positionOutHeight=$("div.position_out").height()+7;//“全部分类”那一部分的高度，7是padding-top
					var topVlaue=darenInfomationHeight+headHeight+darenTitleHeight+darenSearchHeight+positionOutHeight+5;//加5是因为要和按钮有点间距
					var vTopVlaue=topVlaue+"px";
					$("#sortContain").css("top",vTopVlaue);
					 
					 var reg = /shopInfo\/$/;
					 if(!reg.test($.trim(iconPath))){
						 $("#"+_this.headIconId).attr("src",iconPath);
					 } 
				 },
				 error:function(){
					 alert("服务器繁忙，请稍后再试。");
				 }
			 });
		};
	//达人页面→达人信息解析_end
		
	//达人页面→搜索按钮,更多筛选按钮点击操作_begin
		var vipSearchButton=function(searchButtonId){
			this.searchButtonId=searchButtonId;
		};
		vipSearchButton.prototype.searchButtonClick=function(){
			var _this=this;
			
			$("#"+_this.searchButtonId).click(function(){
				var url=location.href;
				var zone="";
				var orderBy="";
				var shopid="";
				var shearchValue=$("input#keyword").val();
				if(url.indexOf("?")>0){
					var zonegroup=U.getUrlParam("zonegroup");//大区
					var zoneid=U.getUrlParam("zoneid");//服务器
					orderBy=U.getUrlParam("orderBy");//排序
					shopid=U.getUrlParam("shopid");//店铺id
					if(zoneid){
						zone="&zonegroup="+zonegroup+"&zoneid="+zoneid;
					}else if(zonegroup){
						zone="&zonegroup="+zonegroup;
					}
					url=url.substring(0,url.indexOf("?"));
				}
				location.href=url+"?"+"shopid="+shopid+zone+"&orderBy="+orderBy+"&keyWord="+shearchValue;
				return false;
			});
		};
		vipSearchButton.prototype.moreDetailChoiceClick=function(){
			$("#moreDetailChoice").click(function(){
				var url=location.href;
				
				var shopid="";
				var basePath=$("#basePathId").attr("value");
				var shearchValue=$("input#keyword").val();
				if(url.indexOf("?")>0){
					
					shopid=U.getUrlParam("shopid");//店铺id
					
					//url=url.substring(0,url.indexOf("?"));
				}
				location.href=basePath+"jsp/myshop/zoneSearch.jsp@shopid="+shopid;
				return false;
			});
		};
	//达人页面→搜索按钮点击操作_end
		

		var StringBuffer = function (){
			this.content = [];
		};
		StringBuffer.prototype.append = function (str){
			 this.content.push(str);
			return this;
		};

		StringBuffer.prototype.toString = function (splitStr){
			if(splitStr){
				return this.content.join(splitStr);
			}else{
				return this.content.join("");
			}
		};
		
	//达人→更多筛选页面取大区与服务器_begin
		var moreSearch=function(aidId,selectGroupId,selectZoneId,sureButtonId,cancleButtonId,basePathId){
			this.aidId=aidId;
			this.selectGroupId=selectGroupId;//选择游戏大区的select的Id
			this.selectZoneId=selectZoneId;//选择游戏服务器的select的Id
			this.sureButtonId=sureButtonId;//”确定“按钮Id
			this.cancleButtonId=cancleButtonId;//"取消"按钮Id
			this.basePathId=basePathId;
		};
		moreSearch.prototype.getZoneGroup=function(){//获取游戏大区
			var _this=this;
			
			var flag = false;
			var aid=$("#"+_this.aidId).attr("value");
			//var domainUrl = $("#domainPathId").attr("value");
			var domainUrl="../";
			//var domainUrl="../../localhost_3A8080/178_games";
			//var gamesDomain=domainUrl+'/games';
			var gamesDomain=domainUrl+'/gamesMobile';
			$.ajax({
				type : "get",
				url : gamesDomain+"/gamesServlet?key=forzonegroup&aid="+aid,
				cache : true,
				async : false,
				dataType : "xml",
				success : function(data, textStatus) {
					var strHtml = new StringBuffer();
					strHtml.append("<option title=''>请选择游戏大区</option>");
					$(data).find('group').each(function (i){
						var name = $(this).text();
						strHtml.append("<option title='"+name+"'>"+name+"</option>");
					});
					$("#"+_this.selectGroupId).html(strHtml.toString());
				},
				error : function(XMLHttpRequest, textStatus, errorThrown) {
					alert('服务器繁忙请稍后再试！');
				}
			});
			return flag;
		};
		moreSearch.prototype.zoneGroupChange=function(){//选择游戏大区联动查询游戏服务器
			var _this=this;
			$("#"+_this.selectGroupId).change(function(){
				_this.getServerZone();
			});
		};
		moreSearch.prototype.getServerZone=function(){//初始化游戏服务器
			var _this=this;
			
			var flag = false;
			var aid=$("#"+_this.aidId).attr("value");
			//var domainUrl = $("#domainPathId").attr("value");
			var domainUrl="../";
			//var domainUrl="../../localhost_3A8080/178_games";
			var gamesDomain=domainUrl+'/gamesMobile';
			//var gamesDomain=domainUrl+'/games';
			var zoneGroup=$("#"+_this.selectGroupId+" option:selected").attr("title");
			if(zoneGroup==""){
				$("#"+_this.selectZoneId).html("<option title=''>请选择游戏服务器</option>");
				return false;			
			}
			$.ajax({
				type : "get",
				url : gamesDomain+"/gamesServlet?key=forzone&zoneGroup="+encodeURIComponent(zoneGroup)+"&aid="+aid,
				cache : true,
				async : false,
				dataType : "xml",
				success : function(data, textStatus) {
					var strHtml = new StringBuffer();
					strHtml.append("<option title=''>请选择游戏服务器</option>");
					$(data).find('zone').each(function (i){
						var texts = $(this).text().split(":");
						var id = texts[0];
						var name = texts[1];
						strHtml.append("<option title='"+id+"'>"+name+"</option>");
					});
					$("#"+_this.selectZoneId).html(strHtml.toString());
				},
				error : function(XMLHttpRequest, textStatus, errorThrown) {
					alert('服务器繁忙请稍后再试！');
				}
			});		
		};
		moreSearch.prototype.buttonOpera=function(){//两个按钮，”确定“，”取消“的操作
			var _this=this;
			
			var basePathValue=$("#"+_this.basePathId).attr("value");
			var url=location.href;
			var shopid=U.getUrlParam("shopid");
			
			$("#"+_this.cancleButtonId).click(function(){//点击”取消“按钮，返回达人页面
				location.href=basePathValue+"search?"+"shopid="+shopid;				
			});
			
			$("#"+_this.sureButtonId).click(function(){
				var zonegroup=$("#"+_this.selectGroupId+" option:selected").attr("title");//游戏大区
				var zoneServer=$("#"+_this.selectZoneId+" option:selected").attr("title");//服务器
				if(zoneServer!=""){//如果被选中的服务器的title值不为空的话，点击“确定”按钮
					location.href=basePathValue+"search?"
					+"shopid="+shopid+"&zonegroup="+zonegroup
					+"&zoneid="+zoneServer;	
				}else if(zonegroup!=""){
					location.href=basePathValue+"search?"+"shopid="+shopid+"&zonegroup="+zonegroup;
				}else{
					location.href=basePathValue+"search?"+"shopid="+shopid;
				}
			});
		};
	//达人→更多筛选页面取大区与服务器_end
		
	//
		var mobileCode=function(){
			
		};
		mobileCode.prototype.sendMobileCode=function(){
			$.ajax({
				type: "POST",
		    	dataType: "xml",
		    	cache:false,
		   		url: "sendMobileCode.do",
		   		data: {},
		   		success: function(xml){	
			   			var statusCode = $(xml).find("statusCode").text();		   			
				   		var message = $(xml).find("message").text();
				   		if(statusCode=="200") {
					   		if(message=="0"){
					   			var oPop = new Pop("", "验证码发送成功！", "popup");
					   			oPop.popAlert();
						   	}else if(message=='2'){
						   		var oPop = new Pop("提示", "请先绑定手机！", "popup");
						   		oPop.popAlert();
								//$("#popSure").attr('href','${pagePath}/security/securitymobile.do@method=setMobileView').attr('target','_blank');
								$("#popSure").unbind("click").click(function (){
									$("#popMask").remove();
									$("#hiddenPop").hide();
								});
							 }else if(message=="-1"){
								 var oPop = new Pop("提示", "请求过于频繁！", "popup");
								 oPop.popAlert();
							}else if(message=="1"){
								 alert("服务器繁忙请稍后再试！");
							}else{
								 alert("服务器繁忙请稍后再试！");
							}
				   		} else if(statusCode=="302"){
				   			var href = $(xml).find("redirectURL").text();
				   			var oPop = new Pop("请您登录", "登录后才能进行该操作，您要登录吗？", "popup", function() {location.href = href;});
							pop.popConfirm();
				   		} else {
				   			var oPop = new Pop("", message, "popup");
				   			oPop.popAlert();
				   		}
		   		}	
			});
		};
	//
		
	//"未上架"页面，"取消寄售"按钮操作_begin
		var salePost=function(upButtonClass,itemListId,moreFlagClass,PagiongFlagClass,upDetailId,upInfoDetail,needAuthCode){
			this.upButtonClass=upButtonClass;//“上架”按钮Id
			this.itemListId=itemListId;//物品列表Id
			this.moreFlagClass=moreFlagClass;//"更多"按钮标记样式
			this.PagiongFlagClass=PagiongFlagClass;//"分页"标记样式
			this.upDetailId=upDetailId;//上架时的物品信息展示栏的Id
			this.upInfoDetail=upInfoDetail;//上架时信息填写栏的Id
			this.needAuthCode=needAuthCode;
		};
		salePost.prototype.upButtonClick=function(){//点击上架按钮操作
			var _this=this;
			$("."+_this.upButtonClass).each(function(){
				$(this).click(function(){
					$("#"+_this.itemListId).hide();//隐藏物品信息页
					$("#"+_this.itemListId).siblings("ul."+_this.moreButtonFlag).hide();//隐藏“更多”按钮
					$("#moreButton").hide();
					$("#"+_this.itemListId).siblings("div."+_this.PagiongFlagClass).hide();//隐藏分页栏
					
					$("#"+_this.upDetailId).show();//物品信息展示栏显示
					$("#"+_this.upInfoDetail).show();//物品信息填写栏显示
					
					var name=$(this).parents("span.itemSpanFlag").prev("div.itemHiddenInformation").find("input.nameFlag").attr("value");
					var sellerName=$(this).parents("span.itemSpanFlag").prev("div.itemHiddenInformation").find("input.salerFlag").attr("value");
					var postTime=$(this).parents("span.itemSpanFlag").prev("div.itemHiddenInformation").find("input.postTimeFlag").attr("value");
					var postEndTime=$(this).parents("span.itemSpanFlag").prev("div.itemHiddenInformation").find("input.endTimeFlag").attr("value");
					var grade=$(this).parents("span.itemSpanFlag").prev("div.itemHiddenInformation").find("input.gradeFlag").attr("value");
					
					var commid=$(this).parents("span.itemSpanFlag").prev("div.itemHiddenInformation").find("input.commidFlag").attr("value");
					var sn=$(this).parents("span.itemSpanFlag").prev("div.itemHiddenInformation").find("input.snFlag").attr("value");
					//var restShowPeriod=$(this).parents("span.itemSpanFlag").prev("div.itemHiddenInformation").find("input.restShowPeriodFlag").attr("value");
					var restShowMillionSecond=$(this).parents("span.itemSpanFlag").prev("div.itemHiddenInformation").find("input.restShowMillionSecondFlag").attr("value");				
					var isSameIp=$(this).parents("span.itemSpanFlag").prev("div.itemHiddenInformation").find("input.sameipFlag").attr("value");
					var nextPrice=$(this).parents("span.itemSpanFlag").prev("div.itemHiddenInformation").find("input.priceFlag").attr("value");
					var isRole;
					var isRoleTemp=$(this).parents("span.itemSpanFlag").prev("div.itemHiddenInformation").find("input.isRoleFlag").attr("value");
					if(isRoleTemp=="true"){
						isRole="true";
					}else{
						isRole="false";
					}
					
					if(parseInt(grade)<=0) {
						grade = "--";
					}
					
					$("#inform_roleName").html(name);
					$("#inform_sellerName").html(sellerName);
					$("#infom_level").html(grade);
					$("#infom_post").html(postTime);
					$("#infom_endTime").html(postEndTime);
					$("#hiddenCommid").attr("value",commid);
					$("#hiddenSn").attr("value",sn);
					$("#hiddenRestShowMillionSecond").attr("value",restShowMillionSecond);
					$("#hiddenIsRole").attr("value",isRole);
					$("#hiddenIsSameIp").attr("value",isSameIp);
					$("#hiddenNextPrice").attr("value",nextPrice);
				});
			});
		};
		salePost.prototype.appointBuyerClick=function(){//指定买家
			var _this=this;
			$("#appointBuyer").click(function(){
				if($(this)[0].checked){
					$("#appointBuyerName").slideDown();
				}else{
					$("#appointBuyerName").slideUp();
					$("#appointBuyerErrorNotice").html("");
					$("#li_appointBuyerErrorNotice").hide();
				}
			});
		};
		salePost.prototype.InputlooseBlur=function(){
			var _this=this;
			var oNumCheck=new numCheck();
			var oMobileCode=new mobileCode();
			$("#itemSubmitPrice").blur(function(){
				var price=$("#itemSubmitPrice").val();
				var isRole=$("#hiddenIsRole").attr("value");
				if(isRole=="true"){
					isRole=true;
				}else{
					isRole=false;
				}
				var isSameIp=$("#hiddenIsSameIp").attr("value");
				var nextPrice=$("#hiddenNextPrice").attr("value");
				if(!oNumCheck.check_float(price, isRole)) {
					$("#priceErroeInfo").html("请输入大于等于十(角色必须大于等于六十)、小于等于一百万的实数(最多两位小数)");
					$("#li_priceErroeInfo").show();
					return false;
				}else{
					$("#priceErroeInfo").html();
					$("#li_priceErroeInfo").hide();
				}
				if(isRole){
					var price = $(this).val();
					$("#getAuthCode").unbind("click");
					$("#auth_code_panel").hide();
					if($.trim(isSameIp)=="false") {//ip不同
						if(parseInt(nextPrice) == 0 || parseFloat(nextPrice) > parseFloat(price)) {//加个为0说明没有上过架
							/*if(parseInt(nextPrice) == 0){
								$('#next_price_inf').text('');
							}else if(parseFloat(nextPrice) > parseFloat(price)){
								$('#next_price_inf').text('此次修改价格比原价格('+nextPrice+'元)低,');
							}*/
							_this.needAuthCode = true;
							$("#auth_code_panel").show();
							$('#getAuthCode').unbind("click").bind("click",function (){
								oMobileCode.sendMobileCode();//绑定获取验证码按钮访问服务器
							});
						}else{//如果不需要验证码就,取消绑定方法，不显示验证码的提示面板
							_this.needAuthCode = false;
							$('#getAuthCode').unbind('click');
							$("#auth_code_panel").hide();
						}
					}
				}
			});
			$("#itemSubmitUpDay").blur(function(){//“销售天数”输入框失去焦点时进行的数据合法性验证
				var upDay=$("#itemSubmitUpDay").val();
				var postEndTime=oNumCheck.parseDate($("#infom_endTime").html());
				var restShowMillionSecond= parseFloat($("#hiddenRestShowMillionSecond").attr("value"));
				if(!oNumCheck.check_integer(upDay)){
					$("#upDayErrorNotice").html("请输入大于零的整数");
					$("#li_upDayErrorNotice").show();
				}else if(postEndTime.getTime() < new Date().getTime() + restShowMillionSecond + parseInt(upDay)*24*60*60*1000){
					$("#upDayErrorNotice").html("您输入的销售天数加上公示时间已超过了寄售结束时间");
					$("#li_upDayErrorNotice").show();
				}else{
					$("#upDayErrorNotice").html("");
					$("#li_upDayErrorNotice").hide();					
				}
			});
			$("#submitbroleName").blur(function(){//指定买家角色输入框失去焦点时进行的数据合法性验证
				var specify = $("#appointBuyer").attr("checked")=="checked";
				
				var broleName=$("#submitbroleName").val();
				if(specify) {
					if(!$.trim(broleName)) {
						$('#appointBuyerErrorNotice').html("角色名不能为空");
						$('#li_appointBuyerErrorNotice').show();
					}else if($.trim(broleName).length>10) {
						$('#appointBuyerErrorNotice').html("角色名不能过长");
						$('#li_appointBuyerErrorNotice').show();
					}else{
						$("#appointBuyerErrorNotice").html("");
						$("#li_appointBuyerErrorNotice").hide();
					}										
				}
			});
		};
		salePost.prototype.upSumitButtonClick=function(){
			var _this=this;
			$("#itemUp").click(function(){	
				
				var oNumCheck=new numCheck();
				var commid=$("#hiddenCommid").attr("value");
				var sn=$("#hiddenSn").attr("value");
				var restShowMillionSecond=parseFloat($("#hiddenRestShowMillionSecond").attr("value"));
				var price=$("#itemSubmitPrice").val();
				var postTime=oNumCheck.parseDate($("#infom_post").html());
				var postEndTime=oNumCheck.parseDate($("#infom_endTime").html());
				var upDay=$("#itemSubmitUpDay").val();
				var specify=$("#appointBuyer").attr("checked") == "checked";
				var broleName=$("#submitbroleName").val();
				var authCode=$("#phonecode").val();
				var isRole=$("#hiddenIsRole").attr("value");
				if(isRole=="true"){
					isRole=true;
				}else{
					isRole=false;
				}
				
				if(!oNumCheck.check_float(price, isRole)) {
					$("#priceErroeInfo").html("请输入大于等于十(角色必须大于等于六十)、小于等于一百万的实数(最多两位小数)");
					$("#li_priceErroeInfo").show();
				}
				
				if(!oNumCheck.check_integer(upDay)){
					$("#upDayErrorNotice").html("请输入大于零的整数");
					$("#li_upDayErrorNotice").show();
					return false;
				}else if(upDay==postEndTime.getTime() < new Date().getTime() + restShowMillionSecond + parseInt(upDay)*24*60*60*1000){
					$("#upDayErrorNotice").html("您输入的销售天数加上公示时间已超过了寄售结束时间");
					$("#li_upDayErrorNotice").show();
					return false;
				}
				if(specify){
					if(!$.trim(broleName)) {
						$('#appointBuyerErrorNotice').html("角色名不能为空");
						$('#li_appointBuyerErrorNotice').show();
						return false;
					}else if($.trim(broleName).length>10) {
						$('#appointBuyerErrorNotice').html("角色名不能过长");
						$('#li_appointBuyerErrorNotice').show();
						return false;
					}
				}
				
				if(_this.needAuthCode){
					if($.trim(authCode).length!=4){
			   			var oPop = new Pop("","请输入验证码", "popup");
			   			oPop.popAlert();
			   			return false;
					}
				}
				price = parseInt(parseFloat(price) * 100);
				
				$.ajax({
			    	type: "POST",
			   		url: "upSalePost.do",
			   		data: { "commid": commid, "price":price, "upDay":upDay, "sn":sn,
				   		"specify":specify, "broleName":broleName,"authCode":authCode},
			   		success: function(xml){
				   			var statusCode = $(xml).find("statusCode").text();
					   		var message = $(xml).find("message").text();
					   		if(statusCode=="200") {
					   			var oPop = new Pop("", message, "popup", function() {location.href = "sale.do@status=post";});
					   			oPop.popAlert();
					   		} else if(statusCode=="302"){
					   			var href = $(xml).find("redirectURL").text();
					   			var oPop = new Pop("请您登录", "登录后才能进行该操作，您要登录吗？", "popup", function() {location.href = href;});
					   			oPop.popConfirm();
					   		} else {
					   			var oPop = new Pop("", message, "popup");
					   			oPop.popAlert();
					   		}
			   		}	
				}); 							
			});
			
		};
		salePost.prototype.itemCancleClick=function(){
			var _this=this;
			$("#itemCancle").click(function(){
				$("#itemSubmitPrice").attr("value","");//价格栏清空
				$("#priceErroeInfo").html("");//价格输入错误提示清空
				$("#li_priceErroeInfo").hide();//价格输入错误提示隐藏
				
				$("#itemSubmitUpDay").attr("value","");//上架时间栏清空
				$("#upDayErrorNotice").html("");//上架时间输入错误提示清空
				$("#li_upDayErrorNotice").hide();//上架时间输入错误提示隐藏
				
				$("#submitbroleName").attr("value","");//指定玩家名称栏清空
				$("#appointBuyerErrorNotice").html("");//玩家名称输入错误提示清空
				$("#li_appointBuyerErrorNotice").hide();//玩家名称输入错误提示隐藏
				
				$("#appointBuyer")[0].checked=false;//“指定买家角色”复选框取消选中
				
				$("#"+_this.upDetailId).hide();//物品信息展示栏隐藏
				$("#"+_this.upInfoDetail).hide();//物品信息填写栏隐藏
				$("#"+_this.itemListId).show();//显示物品信息页
				$("#"+_this.itemListId).siblings("ul."+_this.moreButtonFlag).show();//显示“更多”按钮
				$("#"+_this.itemListId).siblings("div."+_this.PagiongFlagClass).show();//显示分页栏
				
				
			});
		};
	//"未上架"页面，"取消寄售"按钮操作_end
		
	//我的购物车付款时的订单详情_begin
	var prePay=function(prePayBuyButtonId){
		this.prePayBuyButtonId=prePayBuyButtonId;
	};
	prePay.prototype.prePayButtonClick=function(){
		var _this=this;
		$("#"+_this.prePayBuyButtonId).click(function(){
			var orderId=$("#orderId").attr("value");
	    	var ext1=$("#ext1").attr("value");
	    	$.ajax({
	    		type: "POST",
	    		url: "pay.do",
	    		data: {"orderId": orderId, "ext1" : ext1},
	    		success: function(xml){
	    			var statusCode = $(xml).find("statusCode").text();
	    	   		var message = $(xml).find("message").text();
	    	   		if(statusCode=="200") {
	    	   			$("#frm").submit(); 
	    	   		}else if(statusCode=='302'){
	    	   			var href = $(xml).find("redirectURL").text();
	    	   			var oPop = new Pop("请您登录", "登录后才能进行该操作，您要登录吗？", "popup", function() {location.href = href;});
			   			oPop.popConfirm();
	    	   		}else {
	    	   			var oPop = new Pop("", message, "popup");
			   			oPop.popAlert();
	    	   		}
	    		}
	    	});
		});
	};
	//我的购物车付款时的订单详情_end
		
	//页面圆盘控制区操作_begin
		var circleControl=function(circleButtonId,maskId,circlePanelId){
			this.circleButtonId=circleButtonId;
			this.circlePanelId=circlePanelId;
			this.maskId=maskId;			
		};
		circleControl.prototype.controlFunction=function(){
			var _this=this;
			$("#"+_this.circleButtonId).click(function(){
				$("#"+_this.circlePanelId).toggle();
				$("#"+_this.maskId).toggle();
				if($(this).hasClass("on")){
					$(this).removeClass("on").addClass("off");
				}else if($(this).hasClass("off")){
					$(this).removeClass("off").addClass("on");
				}
			});
			$("#"+_this.maskId).click(function(){
				$("#"+_this.circlePanelId).hide();
				$("#"+_this.maskId).hide();
				$("#circleButton").removeClass("off").addClass("on");
			});
		};
	//页面圆盘控制区操作_end
		
	var homeButtnControl=function(){
		
	};
	homeButtnControl.prototype.homeButtnControlFun=function(){
		var url=location.href;
		if(url.indexOf("buy.gsp")!=-1){
			$("#head_home_button").attr("href","../");
		};
	};
	
	
	
		
	
	$("document").ready(function(){
		//回顶部_begin
		$("#imge_backToTop").live("click",function(){
			$("body").animate({scrollTop:0},100);
		});
		$("#f_backToTop").live("click",function(){
			$("body").animate({scrollTop:0},100);
		});
		//回顶部_end

		
		//判断用户是否被封禁
		var oIsForbid=new isForbid("confirmForbid","forbidText");
		oIsForbid.isForbidJudge();//${forbidNotice}
		//判断用户是否被封禁
	});
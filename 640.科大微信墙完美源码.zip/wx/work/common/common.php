<?php

#下面定义的是一些警告提示表情
define('LINE',"\n------\n");
define('♥','');
define('★','');
define('HAND','');
define('XX','');
define('II','');
define('III','');
define('NEWO','');



//用户关注时欢迎信息
//define('WELCOME',♥."欢迎关注辽科大助手".♥."\n在这里，您可以方便的获取到辽科大各方面的信息\n".II."试试回复下面的关键字吧：".LINE.NEWO."\n".NEWO."\n".NEWO."\n".HAND."\n".HAND."\n".HAND."糗百/天气\n".HAND."test\n".NEWO."\n".HAND."热词/每日一句\n".HAND."反馈/关于\n---\n".III."用户串：");




//用户菜单
//define('MENU',"现在您可以回复：".LINE.NEWO."\n".NEWO."\n".NEWO."\n".HAND."\n".HAND."糗百/天气\n".HAND."test\n".NEWO."\n".HAND."热词/每日一句\n".HAND."反馈/关于".LINE.III."用户串：");

$(document).ready(function() {
    initCommonFunc();
    lazyLoadImgMore();
    skuCollect();
});

function initCommonFunc() {
    /* close top app info */
    $('.app-close').click(function() {
        $('.app-info').slideToggle();
        setCookie('popup_app','true',5760,'bbbao.com');
    });

    /* check top app info show */
    if ( $.cookie('popup_app') ) {
        $('.app-info').hide();
    }

    /* set page title */
    $('.page-title').text(page_title);


    $("input[type='text'], input[type='password']").focus(function(){
        $(this).addClass("i-focus");
        
        if ( $(this).attr('def-value') != null  && $(this).attr('def-value') != undefined ) {
            var def_value = $(this).attr('def-value');
            var val = $(this).val();
            if ( def_value == val ) {
                $(this).val('');
            }
        } 
    });
    $("input[type='text'], input[type='password']").blur(function(){
        $(this).removeClass("i-focus");
        if ( $(this).attr('def-value') != null  && $(this).attr('def-value') != undefined ) {
            var def_value = $(this).attr('def-value');
            var val = $(this).val();
            if ( val == '' ) {
                $(this).val(def_value);
            }
        }
    });

    // 页面底部显示用户登录信息
    if ( $.BT.getUserId() > 0 ) {
        $('.footer-user').html('<a href="auto/taobao_oauth2@v=t">'+$.BT.getDisplayName()+'</a>&nbsp;&nbsp;<a href="logout@v=t">退出</a>');
    }
}

function setCookie(name,value,minute,domain) {
    var exp  = new Date();
    exp.setTime(exp.getTime() + minute*60*1000);
    document.cookie = name + "="+ escape (value) + ";domain=" + domain + ";expires=" + exp.toGMTString()+";path=/";
}


function lazyLoadImgMore() {
    $(".lazy-img-more-loader img").each(function(){
	var img = $(this);
	var src = img.attr("data-src");

	if(src == null || src.indexOf("http://") != 0) {
            return;
	} else {
	    img.hide().attr("src", src);
	}
	img.load(function(){
	    if (this.complete) {
		img.fadeIn().attr("data-src","");
	    }
	});
    });
}

function skuCollect() {
    $('.skuCollect').click(function() {
        var html = '<div class="sku-collect-box" style="font-size:14px;">';
        if ( $.BT.getUserId() == 0 ) {
            html += '<div><a href="auto/taobao_oauth2@v=t">登录</a> 后收藏该商品</div>';
        } else {
            html += '<div style="color:#ff6600;">正在收藏该商品...</div>';
        }
        html += '</div>';

        var url = "../api.bbbao.com/user_api/add_list_item@type=save&url="+encodeURIComponent(window.location.href)+'&url_title='+encodeURI(share_info.name)+'&user_url_title='+encodeURI(share_info.name)+'&url_image_url='+encodeURIComponent(share_info.image_url)+"&v=c";

        $.ajax({
            url: url,
            type: "get",
            dataType : "jsonp",
            jsonp: "jsonCallbackCollect",
            cache:false
        });

        $('body .header').append(html);
    });
}

function jsonCallbackCollect(info) {
   if ( info.status == 'ok' ) {
       $('.sku-collect-box').html('恭喜您收藏成功');
   } else if ( info.status == 'exist' ) {
       $('.sku-collect-box').html('您已经收藏过该商品了');
   } else if ( info.status == 'bad' ) {
       $('.sku-collect-box').html('对不起, 收藏失败');
   }

    setTimeout(function() {
        $('.sku-collect-box').remove();
    }, 5000);
}

function formatFloat(src, pos) {
    return Math.round(src*Math.pow(10, pos))/Math.pow(10, pos);
}

(function($) {
        $.extend({BT:{}});
    $.extend($.BT, {
        getUserId : function () {
            if ( $.BT.getCookieValue('user_id') == undefined || $.BT.getCookieValue('user_id') == '' ) {
                return 0;
            } else {
                return $.BT.getCookieValue('user_id');
            }
        },
        getDisplayName : function () {
            if ( $.BT.getCookieValue('display_name') == undefined || $.BT.getCookieValue('display_name') == '' ) {
                return '';
            } else {
                return $.BT.getCookieValue('display_name');
            }
        },
        getUserLevel : function () {
            if ( $.BT.getCookieValue('user_level') == undefined || $.BT.getCookieValue('user_level') == '' ) {
                return 0;
            } else {
                return $.BT.getCookieValue('user_level');
            }
        },
        getCookieValue : function(name) {
            var user = $.cookie('user');
            if ( user ) {
                user = user.toLowerCase();
                var arrUser = user.split("&");
                for(var i = 0;i < arrUser.length;i ++){
                    var temp = arrUser[i].split("=");
                    if (temp[0] == name ) {
                        return temp[1];
                        break;
                    }
                }
            }
        },
        getCookiePaymentInfoCompleted : function() {
            if ( $.BT.getCookieValue('payment_info_completed') == undefined || $.BT.getCookieValue('payment_info_completed') == '' ) {
                return 1;
            } else {
                return $.BT.getCookieValue('payment_info_completed');
            }           
        },
        acceptNewUserBonus : function() {
            if ( $.BT.getCookieValue('accept_new_user_bonus') == undefined || $.BT.getCookieValue('accept_new_user_bonus') == '' ) {
                return 'n';
            } else {
                return $.BT.getCookieValue('accept_new_user_bonus');
            }
        },
        newUserBonusPoint : function() {
            if ( $.BT.getCookieValue('new_user_bonus_point') == undefined || $.BT.getCookieValue('new_user_bonus_point') == '' ) {
                return 0;
            } else {
                return $.BT.getCookieValue('new_user_bonus_point');
            }
        },
        formatFloat : function(src, pos) {
            return Math.round(src*Math.pow(10, pos))/Math.pow(10, pos);
        },
        trim : function(txt) {
	    if (!txt || txt == '')	return '';
	    var	len=txt.length;
	    var	from=0, i;
	    if (len < 1)	return	txt;
	    for (i=0; i<len; i++) {
		if (txt.charAt(i) != ' ') {
		    from = i;
		    break;
		}
	    }
	    if (i >= len)	return	'';
	    for (i=len-1; i>=0; i--) {
		if (txt.charAt(i) != ' ')	break;
	    }
	    if (i >= len-1) {
		txt = txt.substring(from);
	    } else {
		txt = txt.substring(from, i+1);
	    }
	    return	txt;
        }
    });
})(jQuery);
<?php get_header(); ?>

	<div class="content">
		<div class="postlist">
			<table class="table table-striped content-table" width="700"><tbody>
				<tr style="display:none"><td></td></tr>
				<?php if(have_posts()){while(have_posts()){the_post();
					include('postformat.php'); }?>
			</tbody></table>
			<?php }else{ include('404page.php'); }?>
		</div>
		<div class="pagenavi cf">
			<?php if (  $wp_query->max_num_pages > 1 ) : ?>
				<div id="pagenavi"><?php pagenavi(); ?></div>
			<?php endif; ?><div class="clear"></div>
		</div>
	</div>
<div class="youl">
<div class="youllogo"></div>
<?php wp_list_bookmarks('title_li=&categorize=0'); ?>
</div>
<?php get_footer(); ?>
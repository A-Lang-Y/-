<?php $options = get_option('ice_options');
	if( has_post_format( 'status')) { //Status~?> 
		<div class="status post">
			<div class="title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></div>
			<h2 class="statusavatar left">
				<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark">
					<?php echo get_avatar( get_the_author_email(), '42' ); ?></a>
			</h2>
			<div class="status-content left"> <?php the_content();?></div>
			<div class="clear"></div>
			<span class="status-time right"><?php the_date() ?><?php edit_post_link('[Edit]',' | ','');?></span>
		</div>
<?php } else{ //Default?>
<div id="post-<?php the_ID();?>" class="post">
	<div class="postcon">
		<div class="postinfo">
			<div class="postavatar left"><?php echo get_avatar( get_the_author_email(), '48' ); ?></div>
			<div class="posttitle"><a href="<?php the_permalink();?>" rel="bookmark" title="<?php the_title(); ?>">
			<?php the_title();?></a></div>
			<div class="postdesc"><?php the_time('Y-m-j'); ?> / <?php the_category(', ');?> / 49 次围观 / <?php comments_popup_link('没有评论','1 个评论','% 个评论');?><?php edit_post_link('[Edit]',' / ','');?></div>
		</div><div class="clear"></div>
		
	


		<span class="entry">
			<?php the_content(); ?>


<?php } if($options['sharebar']){ include('sharebar.php'); }?>
	<div class="clear"></div>


			<div class="warning codei"><div class="box-content"><!-- 将此标记放在您希望显示like按钮的位置 -->
<div class="bdlikebutton" style=" float: left; margin-right: 15px; margin-top: 5px; height: 50px;"></div>
<!-- 将此代码放在适当的位置，建议在body结束前 -->
<script id="bdlike_shell"></script>
<script>
var bdShare_config = {
	"type":"medium",
	"color":"red",
	"uid":"6533465",
	"likeText":"喜欢这篇文章",
	"likedText":"您已顶过"
};
document.getElementById("bdlike_shell").src="http://bdimg.share.baidu.com/static/js/like_shell.js?t=" + Math.ceil(new Date()/3600000);
</script>
本博客所有文章如无特别注明均为原创。<br>
复制或转载请以超链接形式注明转自<a href="<?php bloginfo('url') ?>"><?php bloginfo('name') ?></a>，原文地址《<a href="<?php the_permalink();?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title();?></a>》</div></div>
		</span></div>
<div class="sxwz">
<li class="wz1"><?php if (get_previous_post()) { previous_post_link('上一篇： %link','%title',true);} else { echo "上一篇： 没了";} ?></li>
<li class="wz2"><?php if (get_next_post()) { next_post_link('上一篇： %link','%title',true);} else { echo "下一篇： 没了";} ?></li>
</div>
	<?php if($options['relatedpost']) {?>
	<div class="relatebar">	
	<span class="relatetitle">暧昧文章：</span></div>
<div id="wumiiDisplayDiv"></div>
	<div class="clear"></div>
</div>
<div class="clear"></div>			
<?php } //End~ ?></div>
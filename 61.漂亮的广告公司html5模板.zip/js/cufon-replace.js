Cufon.replace('h3, .list-2 .item', { fontFamily: 'NewsGoth', hover:true });
Cufon.replace('.menu li a, h1 strong, .pagination strong, .banner strong', { fontFamily: 'NewsGoth bold', hover:true });
Cufon.replace('h2', { fontFamily: 'Vegur', hover:true });

//
//  FeoPlane.m
//  playAir
//
//  Created by lcc on 13-8-23.
//  Copyright 2013年 __MyCompanyName__. All rights reserved.
//

#import "FeoPlane.h"


@implementation FeoPlane

@synthesize planeType,speed,hp;

@end

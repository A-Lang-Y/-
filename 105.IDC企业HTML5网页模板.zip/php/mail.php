<?php

$email_id = $_POST['email'];   // data from jQuery.post

if(isset($_POST['email'])){
$subject = "You have a new Subscriber";
$to = '99fusion@gmail.com'; //'Youremail@Email.com';    //Change this to your mail address
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

$message = "New Subscriber: ".$email_id;
if ( mail( $to, $subject, $message ) ) {
     echo 'Successfully Subscribed!';
}
} else{
echo 'Unable to subscribe!';
}
?>
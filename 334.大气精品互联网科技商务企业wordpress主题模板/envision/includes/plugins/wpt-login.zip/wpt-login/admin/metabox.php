<?php

add_action('bbp_forum_metabox' , 'wpt_bbps_extend_forum_attributes_mb', 11);

/* the support forum checkbox will add resolved / not resolved status to all forums */
/* The premium forum will create a support forum that can only be viewed by that user and admin users */
function wpt_bbps_extend_forum_attributes_mb($forum_id){
	global $wpt_login;
	$all_items = $wpt_login->all_items();

	$_bbps_supported_item = get_post_meta( $forum_id, '_bbps_supported_item', true);
?>	
	<hr />
	
	<p>
		<strong><?php _e( 'Supported Item:', 'bbps' ); ?></strong>
		<select name="bbps-support-forum-item" style="width:100%;">
	    	<option value="" <?php selected( $item->id, '' ); ?>></option>
			<?php foreach ($all_items as $item) { ?>
		    	<option value="<?php echo $item->id; ?>" <?php selected( $item->id, $_bbps_supported_item ); ?>><?php echo $item->id; ?> - <?php echo $item->item; ?></option>
			<?php } ?>
		</select>
		<br />
	</p>

<?php	
}

//hook into the forum save hook.

add_action( 'bbp_forum_attributes_metabox_save' , 'wpt_bbps_forum_attributes_mb_save' );

function wpt_bbps_forum_attributes_mb_save( $forum_id ){

	//get out the forum meta
	$supported_item = get_post_meta( $forum_id, '_bbps_supported_item' );

	//if we have a value then save it
	if ( ! empty( $_POST['bbps-support-forum-item'] ) ) {
		update_post_meta($forum_id, '_bbps_supported_item', $_POST['bbps-support-forum-item']);
	}
	
	//the forum used to be premium now its not
	if ( ! empty($supported_item) && empty( $_POST['bbps-support-forum-item'] ) ) {
		update_post_meta($forum_id, '_bbps_supported_item', 0);
	}
	
	return $forum_id;

}